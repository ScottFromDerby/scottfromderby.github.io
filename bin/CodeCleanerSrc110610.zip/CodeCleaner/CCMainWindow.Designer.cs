﻿namespace CodeCleaner
{
    partial class frmCCMainWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCCMainWindow));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.tbxDirectoryOpen = new System.Windows.Forms.TextBox();
            this.tbxLog = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.chkRemovePDB = new System.Windows.Forms.CheckBox();
            this.chkRemoveEXE = new System.Windows.Forms.CheckBox();
            this.chkRemoveILK = new System.Windows.Forms.CheckBox();
            this.btnRemove = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.chkRemoveNCB = new System.Windows.Forms.CheckBox();
            this.chkRemoveOBJ = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lblRemovable = new System.Windows.Forms.Label();
            this.chkRemoveCustom = new System.Windows.Forms.CheckBox();
            this.tbxCustomExtension = new System.Windows.Forms.TextBox();
            this.chkRemoveIDB = new System.Windows.Forms.CheckBox();
            this.chkRemovePCH = new System.Windows.Forms.CheckBox();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.aboutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(717, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.exitToolStripMenuItem.Text = "&Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.aboutToolStripMenuItem.Text = "&About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // openFileDialog
            // 
            this.openFileDialog.FileName = "openFileDialog";
            // 
            // tbxDirectoryOpen
            // 
            this.tbxDirectoryOpen.Location = new System.Drawing.Point(107, 31);
            this.tbxDirectoryOpen.Name = "tbxDirectoryOpen";
            this.tbxDirectoryOpen.ReadOnly = true;
            this.tbxDirectoryOpen.Size = new System.Drawing.Size(597, 20);
            this.tbxDirectoryOpen.TabIndex = 2;
            this.tbxDirectoryOpen.Click += new System.EventHandler(this.tbxDirectoryOpen_TextChanged);
            // 
            // tbxLog
            // 
            this.tbxLog.Location = new System.Drawing.Point(46, 61);
            this.tbxLog.Multiline = true;
            this.tbxLog.Name = "tbxLog";
            this.tbxLog.ReadOnly = true;
            this.tbxLog.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tbxLog.Size = new System.Drawing.Size(658, 212);
            this.tbxLog.TabIndex = 3;
            this.tbxLog.Text = "Please specify directory by drag and drop, or by clicking the field above.";
            this.tbxLog.WordWrap = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Current Directory:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(28, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Log:";
            // 
            // chkRemovePDB
            // 
            this.chkRemovePDB.AutoSize = true;
            this.chkRemovePDB.Checked = true;
            this.chkRemovePDB.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkRemovePDB.Location = new System.Drawing.Point(107, 311);
            this.chkRemovePDB.Name = "chkRemovePDB";
            this.chkRemovePDB.Size = new System.Drawing.Size(90, 17);
            this.chkRemovePDB.TabIndex = 5;
            this.chkRemovePDB.Text = "Remove .pdb";
            this.chkRemovePDB.UseVisualStyleBackColor = true;
            this.chkRemovePDB.CheckedChanged += new System.EventHandler(this.chkChanged);
            // 
            // chkRemoveEXE
            // 
            this.chkRemoveEXE.AutoSize = true;
            this.chkRemoveEXE.Location = new System.Drawing.Point(503, 311);
            this.chkRemoveEXE.Name = "chkRemoveEXE";
            this.chkRemoveEXE.Size = new System.Drawing.Size(89, 17);
            this.chkRemoveEXE.TabIndex = 5;
            this.chkRemoveEXE.Text = "Remove .exe";
            this.chkRemoveEXE.UseVisualStyleBackColor = true;
            this.chkRemoveEXE.CheckedChanged += new System.EventHandler(this.chkChanged);
            // 
            // chkRemoveILK
            // 
            this.chkRemoveILK.AutoSize = true;
            this.chkRemoveILK.Checked = true;
            this.chkRemoveILK.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkRemoveILK.Location = new System.Drawing.Point(107, 288);
            this.chkRemoveILK.Name = "chkRemoveILK";
            this.chkRemoveILK.Size = new System.Drawing.Size(82, 17);
            this.chkRemoveILK.TabIndex = 5;
            this.chkRemoveILK.Text = "Remove .ilk";
            this.chkRemoveILK.UseVisualStyleBackColor = true;
            this.chkRemoveILK.CheckedChanged += new System.EventHandler(this.chkChanged);
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(629, 343);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(75, 23);
            this.btnRemove.TabIndex = 6;
            this.btnRemove.Text = "Remove!";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(12, 343);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 7;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // chkRemoveNCB
            // 
            this.chkRemoveNCB.AutoSize = true;
            this.chkRemoveNCB.Checked = true;
            this.chkRemoveNCB.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkRemoveNCB.Location = new System.Drawing.Point(15, 288);
            this.chkRemoveNCB.Name = "chkRemoveNCB";
            this.chkRemoveNCB.Size = new System.Drawing.Size(90, 17);
            this.chkRemoveNCB.TabIndex = 5;
            this.chkRemoveNCB.Text = "Remove .ncb";
            this.chkRemoveNCB.UseVisualStyleBackColor = true;
            this.chkRemoveNCB.CheckedChanged += new System.EventHandler(this.chkChanged);
            // 
            // chkRemoveOBJ
            // 
            this.chkRemoveOBJ.AutoSize = true;
            this.chkRemoveOBJ.Checked = true;
            this.chkRemoveOBJ.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkRemoveOBJ.Location = new System.Drawing.Point(15, 311);
            this.chkRemoveOBJ.Name = "chkRemoveOBJ";
            this.chkRemoveOBJ.Size = new System.Drawing.Size(86, 17);
            this.chkRemoveOBJ.TabIndex = 5;
            this.chkRemoveOBJ.Text = "Remove .obj";
            this.chkRemoveOBJ.UseVisualStyleBackColor = true;
            this.chkRemoveOBJ.CheckedChanged += new System.EventHandler(this.chkChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(503, 348);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Removable:";
            // 
            // lblRemovable
            // 
            this.lblRemovable.AutoSize = true;
            this.lblRemovable.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblRemovable.Location = new System.Drawing.Point(573, 348);
            this.lblRemovable.Name = "lblRemovable";
            this.lblRemovable.Size = new System.Drawing.Size(29, 15);
            this.lblRemovable.TabIndex = 8;
            this.lblRemovable.Text = "N/A";
            // 
            // chkRemoveCustom
            // 
            this.chkRemoveCustom.AutoSize = true;
            this.chkRemoveCustom.Location = new System.Drawing.Point(503, 288);
            this.chkRemoveCustom.Name = "chkRemoveCustom";
            this.chkRemoveCustom.Size = new System.Drawing.Size(154, 17);
            this.chkRemoveCustom.TabIndex = 5;
            this.chkRemoveCustom.Text = "Remove custom extension:";
            this.chkRemoveCustom.UseVisualStyleBackColor = true;
            this.chkRemoveCustom.CheckedChanged += new System.EventHandler(this.chkChanged);
            // 
            // tbxCustomExtension
            // 
            this.tbxCustomExtension.Location = new System.Drawing.Point(663, 286);
            this.tbxCustomExtension.Name = "tbxCustomExtension";
            this.tbxCustomExtension.Size = new System.Drawing.Size(41, 20);
            this.tbxCustomExtension.TabIndex = 9;
            // 
            // chkRemoveIDB
            // 
            this.chkRemoveIDB.AutoSize = true;
            this.chkRemoveIDB.Checked = true;
            this.chkRemoveIDB.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkRemoveIDB.Location = new System.Drawing.Point(205, 289);
            this.chkRemoveIDB.Name = "chkRemoveIDB";
            this.chkRemoveIDB.Size = new System.Drawing.Size(86, 17);
            this.chkRemoveIDB.TabIndex = 5;
            this.chkRemoveIDB.Text = "Remove .idb";
            this.chkRemoveIDB.UseVisualStyleBackColor = true;
            this.chkRemoveIDB.CheckedChanged += new System.EventHandler(this.chkChanged);
            // 
            // chkRemovePCH
            // 
            this.chkRemovePCH.AutoSize = true;
            this.chkRemovePCH.Checked = true;
            this.chkRemovePCH.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkRemovePCH.Location = new System.Drawing.Point(205, 311);
            this.chkRemovePCH.Name = "chkRemovePCH";
            this.chkRemovePCH.Size = new System.Drawing.Size(90, 17);
            this.chkRemovePCH.TabIndex = 5;
            this.chkRemovePCH.Text = "Remove .pch";
            this.chkRemovePCH.UseVisualStyleBackColor = true;
            this.chkRemovePCH.CheckedChanged += new System.EventHandler(this.chkChanged);
            // 
            // frmCCMainWindow
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(717, 377);
            this.Controls.Add(this.tbxCustomExtension);
            this.Controls.Add(this.lblRemovable);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.chkRemoveOBJ);
            this.Controls.Add(this.chkRemoveNCB);
            this.Controls.Add(this.chkRemoveEXE);
            this.Controls.Add(this.chkRemoveCustom);
            this.Controls.Add(this.chkRemovePCH);
            this.Controls.Add(this.chkRemoveIDB);
            this.Controls.Add(this.chkRemoveILK);
            this.Controls.Add(this.chkRemovePDB);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbxLog);
            this.Controls.Add(this.tbxDirectoryOpen);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "frmCCMainWindow";
            this.Text = "CodeCleaner";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.DragEnter += new System.Windows.Forms.DragEventHandler(this.frmMain_DragDrop);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.TextBox tbxLog;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox chkRemovePDB;
        private System.Windows.Forms.CheckBox chkRemoveEXE;
        private System.Windows.Forms.CheckBox chkRemoveILK;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
        private System.Windows.Forms.CheckBox chkRemoveNCB;
        private System.Windows.Forms.CheckBox chkRemoveOBJ;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblRemovable;
        private System.Windows.Forms.CheckBox chkRemoveCustom;
        private System.Windows.Forms.TextBox tbxCustomExtension;
        private System.Windows.Forms.CheckBox chkRemoveIDB;
        private System.Windows.Forms.CheckBox chkRemovePCH;
        public System.Windows.Forms.TextBox tbxDirectoryOpen;
    }
}

