﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CodeCleaner
{
    public partial class frmCCMainWindow : Form
    {
        List<string> m_filesFound;
        long bytesToBeSaved = 0;

        string SensibleFileSizeString(long bytes)
        {
            string retVal;
            if (bytes < 1024)
            {
                retVal = bytes + " b";
            }
            else if (bytes < 1024 * 1024)
            {
                retVal = bytes / (1024) + " kb";
            }
            else
            {
                retVal = bytes / (1024 * 1024) + " mb";
            }

            return retVal;
        }

        void UpdateSpaceSavedLabel()
        {
            lblRemovable.Text = SensibleFileSizeString(bytesToBeSaved);
        }

        void SearchAllFilesInThisDir(string sThisDir, List<string> extensions)
        {                    
            foreach (string f in Directory.GetFiles(sThisDir))
            {
                foreach (string s in extensions)
                {
                    if (f.EndsWith(s, StringComparison.CurrentCultureIgnoreCase))
                    {
                        FileInfo fi = new FileInfo(f);
                        bytesToBeSaved += fi.Length;
                        UpdateSpaceSavedLabel();
                        m_filesFound.Add(f);
                        tbxLog.Text += "(" + SensibleFileSizeString(fi.Length) + ")\t" + f + "\r\n";
                    }
                }
            }
        }

        void DirSearch(string sDir, List<string> extensions)
        {
            try
            {
                SearchAllFilesInThisDir(sDir, extensions);
                foreach (string d in Directory.GetDirectories(sDir))
                {
                    SearchAllFilesInThisDir(d, extensions);
                    DirSearch(d, extensions);
                }
            }
            catch (System.Exception excpt)
            {
                Console.WriteLine(excpt.Message);
            }
        }

        public bool VerifyDirectoryIsGood()
        {
            try
            {
                Directory.GetDirectories(tbxDirectoryOpen.Text);
                return true;
            }
            catch
            {
                //search box is not a directory: should fail!
                tbxLog.Text = "Please specify directory by drag and drop, or " +
                    "by clicking the field above.";
                return false;
            }
        }

        public void SearchForSelectedFiles()
        {
            if (!VerifyDirectoryIsGood())
                return;

            tbxLog.Text = "*Beginning scan of " + tbxDirectoryOpen.Text + "*\r\n";
            m_filesFound.Clear();

            bytesToBeSaved = 0;

            List<string> extensions = new List<string>();

            if ( chkRemoveEXE.Checked )
                extensions.Add("EXE");
            if (chkRemoveILK.Checked)
                extensions.Add("ILK");
            if (chkRemoveNCB.Checked)
                extensions.Add("NCB");
            if (chkRemoveOBJ.Checked)
                extensions.Add("OBJ");
            if (chkRemovePDB.Checked)
                extensions.Add("PDB");
            if (chkRemoveIDB.Checked)
                extensions.Add("IDB");
            if (chkRemovePCH.Checked)
                extensions.Add("PCH");
            if (chkRemoveCustom.Checked && tbxCustomExtension.Text != "" )
                extensions.Add( tbxCustomExtension.Text );

            DirSearch(tbxDirectoryOpen.Text, extensions);

            tbxLog.Text += "*Scan Complete!*";
        }

        public frmCCMainWindow(string startingDir)
        {
            InitializeComponent();
            m_filesFound = new List<string>();
            
            if (startingDir != "")
            {
                tbxDirectoryOpen.Text = startingDir;
                SearchForSelectedFiles();
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("By Scott Davies Feb 2009\nFor more info see www.ImmenseGames.com","About...");
        }

        private void tbxDirectoryOpen_TextChanged(object sender, EventArgs e)
        {
            // verify legal path
            // if so:
            // search for all required files
            // prepare list of files to delete

            folderBrowserDialog.SelectedPath = tbxDirectoryOpen.Text;
            DialogResult dr = folderBrowserDialog.ShowDialog();

            if (dr == DialogResult.Cancel)
                return;

            tbxDirectoryOpen.Text = folderBrowserDialog.SelectedPath;

            SearchForSelectedFiles();
        }

        private void frmMain_DragDrop(object sender, DragEventArgs e)
        {
            IDataObject ido = e.Data;
            Array a = (Array)e.Data.GetData(DataFormats.FileDrop);
            string s = a.GetValue(0).ToString();
            //ido.GetDataPresent(
            //DataFormats.
            try
            {
                tbxDirectoryOpen.Text = s;
                SearchForSelectedFiles();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Unknown error!", ex.ToString());
            }
        }

        private void chkChanged(object sender, EventArgs e)
        {
            SearchForSelectedFiles();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (m_filesFound.Count == 0)
            {
                MessageBox.Show("Nothing to Remove!");
                return;
            }

            bool performedOK = true;

            for (int i = 0; i < m_filesFound.Count(); ++i)
            {
                try
                {
                    string s = m_filesFound[i];
                    File.Delete(s);
                }
                catch ( Exception ex )
                {
                    MessageBox.Show(ex.ToString(), "Error occured: ");
                    performedOK = false;
                }
            }

            if (!performedOK)
                return;

            tbxLog.Text = "Completed! Saved " + lblRemovable.Text + ".\r\n";
            MessageBox.Show("Saved " + lblRemovable.Text + ".", "Done!");

            // Make list of files to be deleted!
            StreamWriter newFile = File.CreateText("./LastDeleted.txt");

            foreach (string s in m_filesFound)
                newFile.WriteLine(s);

            newFile.WriteLine("");
            newFile.Write(SensibleFileSizeString(bytesToBeSaved));
            newFile.WriteLine(" saved at ");
            newFile.WriteLine(DateTime.Now.ToString());

            newFile.Close();

            m_filesFound.Clear();
            bytesToBeSaved = 0;
            UpdateSpaceSavedLabel();
        }

        private void SaveSettings()
        {
            StreamWriter sw = File.CreateText("Settings.txt");

            sw.WriteLine(chkRemoveEXE.Checked);
            sw.WriteLine(chkRemoveIDB.Checked);
            sw.WriteLine(chkRemoveILK.Checked);
            sw.WriteLine(chkRemoveNCB.Checked);
            sw.WriteLine(chkRemoveOBJ.Checked);
            sw.WriteLine(chkRemovePCH.Checked);
            sw.WriteLine(chkRemovePDB.Checked);
            sw.WriteLine(chkRemoveCustom.Checked);
            sw.WriteLine(tbxCustomExtension.Text);

            sw.Close();
        }

        private void LoadSettings()
        {
            StreamReader sr = File.OpenText("Settings.txt");

            chkRemoveEXE.Checked = sr.ReadLine() == "True";
            chkRemoveIDB.Checked = sr.ReadLine() == "True";
            chkRemoveILK.Checked = sr.ReadLine() == "True";
            chkRemoveNCB.Checked = sr.ReadLine() == "True";
            chkRemoveOBJ.Checked = sr.ReadLine() == "True";
            chkRemovePCH.Checked = sr.ReadLine() == "True";
            chkRemovePDB.Checked = sr.ReadLine() == "True";
            chkRemoveCustom.Checked = sr.ReadLine() == "True";
            tbxCustomExtension.Text = sr.ReadLine();

            sr.Close();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            // Create settings file if it doesn't exist
            if ( !File.Exists("Settings.txt") )
            {
                FileStream temp = File.Create("Settings.txt");
                temp.Close();
                SaveSettings();
            }

            // Load settings from file
            LoadSettings();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Save settings!
            SaveSettings();
        }
    }

    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            if (args.Length > 0)
                Application.Run(new frmCCMainWindow(args[0].ToString()));
            else
                Application.Run(new frmCCMainWindow(""));
        }
    }
}
