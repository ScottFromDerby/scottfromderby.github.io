﻿using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace CopyCollector
{
    public partial class Form1 : Form
    {
        [DllImport("User32.dll")]
        protected static extern int SetClipboardViewer(int hWndNewViewer);

        [DllImport("User32.dll", CharSet = CharSet.Auto)]
        public static extern bool ChangeClipboardChain(IntPtr hWndRemove, IntPtr hWndNewNext);

        [DllImport("User32.dll", CharSet = CharSet.Auto)]
        public static extern int SendMessage(IntPtr hwnd, int wMsg, IntPtr wParam, IntPtr lParam);

        IntPtr clipBoardViewer;

        public Form1()
        {
            InitializeComponent();
            clipBoardViewer = (IntPtr)SetClipboardViewer((int)this.Handle);
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            ChangeClipboardChain(this.Handle, clipBoardViewer);
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        protected override void WndProc(ref Message m)
        {
            // defined in winuser.h
            const int WM_DRAWCLIPBOARD = 0x308;
            const int WM_CHANGECBCHAIN = 0x030D;

            switch (m.Msg)
            {
                case WM_DRAWCLIPBOARD:
                    GrabClipboardData();
                    SendMessage(clipBoardViewer, m.Msg, m.WParam, m.LParam);
                    break;

                case WM_CHANGECBCHAIN:
                    if (m.WParam == clipBoardViewer)
                        clipBoardViewer = m.LParam;
                    else
                        SendMessage(clipBoardViewer, m.Msg, m.WParam, m.LParam);
                    break;

                default:
                    base.WndProc(ref m);
                    break;
            }
        }

        private static bool firstGrab = true;

        void GrabClipboardData()
        {
            // ignore first GrabClipboardData() - this stops the app
            // from displaying data already in your clipboard
            if (firstGrab)
            {
                firstGrab = false;
                return;
            }

            try
            {
                IDataObject dataObj = new DataObject();
                dataObj = Clipboard.GetDataObject();

                if (dataObj.GetDataPresent(DataFormats.Rtf))
                    tbxMain.Text += (string)dataObj.GetData(DataFormats.Text) + Environment.NewLine;
                else if (dataObj.GetDataPresent(DataFormats.Text))
                    tbxMain.Text += (string)dataObj.GetData(DataFormats.Text) + Environment.NewLine;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
        }

        private void tbxMain_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            tbxMain.Text = "";
        }
    }

    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
