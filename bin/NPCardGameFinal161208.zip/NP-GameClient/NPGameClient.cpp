#include <stdlib.h>
#include <conio.h>

#include "SDL.h"
#include "SDL_net.h"
#include "SDL_thread.h"
#include "SDL_image.h"

#include <assert.h>
#include <deque>
#include <string>
#include <math.h>
#include <time.h>

#include "../NP-Shared/NPGameState.h"
#include "../NP-Shared/SDLRenderer.h"
#include "../NP-Shared/NPNetworkInterface.h"
#include "../NP-Shared/NPImageBank.h"
#include "../NP-Shared/NPMessageTypes.h"
#include "../NP-Shared/NPHelper.h"
#include "../NP-Shared/NPCard.h"

#define SCREEN_WIDTH		640
#define SCREEN_HEIGHT		480
#define DEFAULT_CLIENT_NAME "Client"
#define FONT_PATH			"..\\NP-Shared\\Resources\\lucon.ttf"

#define CLIENT_VERSION "1.000"

#define MAX_TEXT_CHAT_LINES 18
#define MAX_TEXT_CHAT_LINES_INGAME 6

#define DEFAULT_LOCAL_PORT		5000
#define DEFAULT_SERVER_ADDRESS	"127.0.0.1"
#define DEFAULT_SERVER_PORT		5500

// exposed for mouse-click sake
const short CARD_SIZE_X        = 100;
const short CARD_SIZE_Y        = 140;
const short SMALL_CARD_SIZE_X  = 32;
const short SMALL_CARD_SIZE_Y  = 45;
const short DECK_X             = 20;
const short DECK_Y             = 110;
const short PLAYER_CARDS_X     = 10;
const short PLAYER_CARDS_Y     = 280;

const short PLY_CARD_COLUMNS   = 7;
const short SMALL_CARD_SPACING_X = 3;
const short SMALL_CARD_SPACING_Y = 4;

const char symbolsOKtoSend[28] = "!\"�$%^&*(),./;'#[]<>?:@~{}\\"; // Symbols that are acceptable chat input

// Message reasons for screen-space clicks
enum CLICK_MSG_RETURN{ CLICK_NULL, CLICK_CARD_STANDARD, CLICK_CARD_DECK, CLICK_HELP };

SDLRenderer *			 g_pRenderer;			// the simple SDL rendering iterface
NPImageBank *			 g_pImageBank;			// the image bank used for drawing 2D sprites

NPNetworkInterface *	 g_pNetworkInterface;	 // the client's Network Interface object
std::vector<std::string> g_chatroomParticipants; // names of the chat participants 
std::string				 g_userMsgToSend;		// the message the client has typed (so far)
std::deque<std::string>  g_vChatMessages;		 // previously received chat messages

char					 g_clientName[127];		// the client's name ( initially Client### )
GameState				 g_currentGameState;	// the current gamestate (see NPGameState.h)

time_t					 g_lastServerPing;		// the time when a ping was last sent to the server
bool					 g_waitingPingResponse;	// whether we are currently awaiting a ping response

std::vector<NPCard>		 g_gameCards;			// the player's cards
int						 g_gameOppCards[3];		// the number of cards each opponent has
std::string				 g_gamePlayers[3];		// opponent player names
NPCard					 g_activeCard( NPCARDTYPE_NULL, 0 ); // the card on the top of the stack
bool					 g_myTurn = true;		// whether it is this player's turn or not.
unsigned int			 g_gameHash = 0;		// the unique identifier of the game in progress
	
// Here setup the static int hash to identify this client!
unsigned int NPNetworkInterface::m_interfaceHash = (unsigned int)time(NULL);

// debug: all multiple clients on this one PC?
bool					g_multClients = false;

CLICK_MSG_RETURN ProcessClick(short x, short y, unsigned short& whichCardIndex)
{
	// short routine to detect whether a click was within one of the set 
	// RECT boundaries of where the cards get drawn
	// returns the index of which card box was clicked
	// or 0 for none
	
	if ( g_currentGameState == GAMESTATE_INGAME )
	{
		if ( x > DECK_X && x < DECK_X + CARD_SIZE_X &&
			 y > DECK_Y && y < DECK_Y + CARD_SIZE_Y )
		{
			// player clicked the deck - pickup!
			whichCardIndex = 1000;
			return CLICK_CARD_DECK;
		}
		else
		{
			// Check against player cards
			short iter = 0;
			for ( int i = 1; i < 4; ++i )
			{
				for ( int j = 1; j < PLY_CARD_COLUMNS+1; ++j )
				{
					if ( x > PLAYER_CARDS_X + ( SMALL_CARD_SIZE_X+SMALL_CARD_SPACING_X ) * (j-1) &&
						 x < PLAYER_CARDS_X + ( SMALL_CARD_SIZE_X+SMALL_CARD_SPACING_X ) * j )
					{
						if ( y > PLAYER_CARDS_Y + ( SMALL_CARD_SIZE_Y+SMALL_CARD_SPACING_Y ) * (i-1) &&
							 y < PLAYER_CARDS_Y + ( SMALL_CARD_SIZE_Y+SMALL_CARD_SPACING_Y ) * i )
						{
							whichCardIndex = iter;
							return CLICK_CARD_STANDARD;
						}
					}
					iter++;
				}
			}
			// other click areas?
		}
	}

	return CLICK_NULL;
}

bool DoChatCommand()
{
	// returns true if this was a 'command', not a chat message.
	// Note: remember the double backslash!!
	bool successful = false;

	const char* inCommand = g_userMsgToSend.c_str();

	if ( g_userMsgToSend.size() == 0 )
	{
		// empty msg: swallow it... saves processing it later
		successful = true;
	}
	else if ( strncmp( inCommand, "\\name", 5 ) == 0 )
	{
		// Change nickname in chat
		std::string temp = g_userMsgToSend.substr( 6 ); // including leading space after '\name'
		sprintf_s(g_clientName, temp.size()+1, temp.c_str() );

		// Tell the server!
		NPNetMessage newMsg( g_pNetworkInterface->GetLocalIPAddress(),
							 g_pNetworkInterface->GetRemoteIPAddress(),
							 g_clientName,
							 MSG_NAME_UPDATE );

		g_pNetworkInterface->AddNewMessage( newMsg, true );

		successful = true;
	}
	else if ( strncmp( inCommand, "\\info", 5 ) == 0 )
	{
		// View connection info
		char textLine[255];
		char ipAddress[255];

		printf("\n");

		sprintf_s( textLine, 255, "Client Name: %s", g_clientName );
		printf("%s\n", textLine);
		g_vChatMessages.push_back( textLine );
		memset( textLine, ' ', 255 );

		sprintf_s( textLine, 255, "Client Hash: %x", g_pNetworkInterface->Hash() );
		printf("%s\n", textLine);
		g_vChatMessages.push_back( textLine );
		memset( textLine, ' ', 255 );
		
		sprintf_s( textLine, 255, "Client Version: %s", CLIENT_VERSION );
		printf("%s\n", textLine);
		g_vChatMessages.push_back( textLine );
		memset( textLine, ' ', 255 );
		
		IPaddress remoteIPAddress = g_pNetworkInterface->GetRemoteIPAddress();
		NPHelper::GetReadableIPAddress( remoteIPAddress, ipAddress, true );
		sprintf_s( textLine, 255, "Remote IP: %s", ipAddress );
		printf("%s\n", textLine);
		g_vChatMessages.push_back( textLine );
		memset( textLine, ' ', 255 );

		IPaddress localIPAddress = g_pNetworkInterface->GetLocalIPAddress();
		NPHelper::GetReadableIPAddress( localIPAddress, ipAddress, true );
		sprintf_s( textLine, 255, "Local IP: %s", ipAddress );
		printf("%s\n", textLine);
		g_vChatMessages.push_back( textLine );
		memset( textLine, ' ', 255 );

#ifdef _DEBUG
		sprintf_s( textLine, 255, "DEBUG VERSION");
#else
		sprintf_s( textLine, 255, "RELEASE VERSION");
#endif
		printf("%s\n", textLine);
		g_vChatMessages.push_back( textLine );
		memset( textLine, ' ', 255 );

		printf("\n");

		successful = true;
	}
	else if ( strncmp( inCommand, "\\start", 6 ) == 0 )
	{
		// attempt to start game (if 4 players present)
		g_pNetworkInterface->AddNewMessage( NPNetMessage( g_pNetworkInterface->GetLocalIPAddress(),
														  g_pNetworkInterface->GetRemoteIPAddress(),
														  "(Start?)",
														  MSG_START_GAME ), true );
		successful = true;
	}
	else if ( strncmp( inCommand, "\\server", 5 ) == 0 )
	{
		// the client wishes to change the remote IP to connect to
		std::string ip = g_userMsgToSend.substr( 8 ); // including leading space after '\server'

		// parse remainder
		IPaddress destIP = NPHelper::GetIPaddress( ip.c_str(), 0 );
		printf("%s: Changing the remote server address to %s!\n", g_clientName, ip.c_str() );

		g_pNetworkInterface->SetRemoteIPAddress( destIP, false );

		char buffer[40];
		NPHelper::GetReadableIPAddress( destIP, buffer, false );
		sprintf_s( buffer, 40, "Remote server set to %s", buffer );
		g_vChatMessages.push_back( buffer );

		// we set succesful to true no matter what happens to this cmd - we can't sit around and wait for a reply!
		successful = true;
	}
	else if ( strncmp( inCommand, "\\port", 5 ) == 0 )
	{
		// Change the server port
		std::string temp = g_userMsgToSend.substr( 6 ); // including leading space after the command

		if ( temp == "" || atoi(temp.c_str()) > 65535 || atoi( temp.c_str()) <= 0 ) 
		{
			g_vChatMessages.push_back( "Cannot interpret message! Usage: \\port portNumber ");
			return false;
		}

		int newPort = atoi(temp.c_str());
		g_pNetworkInterface->SetRemotePort( newPort );

		char buffer[40];
		sprintf_s(buffer, 40, "Remote port set to %d", newPort );
		g_vChatMessages.push_back( buffer );

		// we set succesful to true no matter what happens to this cmd - we can't sit around and wait for a reply!
		successful = true;
	}
	else if ( strncmp( inCommand, "\\lport", 6 ) == 0 )
	{
		// Change the local port
		std::string temp = g_userMsgToSend.substr( 7 ); // including leading space after the command

		if ( temp == "" || atoi(temp.c_str()) > 65535 || atoi( temp.c_str()) <= 0 ) 
		{
			g_vChatMessages.push_back( "Cannot interpret message! Usage: \\port portNumber ");
			return false;
		}

		int newPort = atoi(temp.c_str());
		g_pNetworkInterface->SetLocalPort( newPort );

		char buffer[40];
		sprintf_s(buffer, 40, "Local port set to %d", newPort );
		g_vChatMessages.push_back( buffer );

		// we set succesful to true no matter what happens to this cmd - we can't sit around and wait for a reply!
		successful = true;
	}
	else if ( strncmp( inCommand, "\\help", 5 ) == 0 )
	{
		// user is asking for help
		g_vChatMessages.push_back( std::string( "Commands are:" ));
		g_vChatMessages.push_back( std::string( "\\info           : displays connection info" ));
		g_vChatMessages.push_back( std::string( "\\name NAME      : change your user name to (NAME)" ));
		g_vChatMessages.push_back( std::string( "\\start          : start a game (requires 4 plyrs)" ));
		g_vChatMessages.push_back( std::string( "\\server 1.2.3.4 : adjust the server IP" ));
		//g_vChatMessages.push_back( std::string( "\\port 5000      : adjust the server port" ));
		//g_vChatMessages.push_back( std::string( "\\lport 5000     : adjust your local port" ));
		g_vChatMessages.push_back( std::string( "Press ESC to quit" ));
		g_vChatMessages.push_back( std::string( "By Scott Davies Sept-Dec 2008" ));


		successful = true;
	}
	else
	{
		// msg cannot be interpretted! - do not empty chatbuffer
		successful = false;
	}

	// if msg was a command - swallow msg!
	if ( successful )
		g_userMsgToSend.clear();

	return successful;
}
void DrawChatField()
{
	const unsigned int CHAT_INNER_COL  = 0xff0066CC;
	const unsigned int CHAT_OUTER_COL  = 0xff004488;
	const unsigned int CHAT_BACK_COL   = 0xff222255;

	const unsigned int CHAT_BOX_TEXT_COL = 0xffeeeeff;

	const unsigned int CHAT_MEMBER_COL = 0xffffffff;

	const short CHAT_BOX_X		  = 30;
	const short CHAT_BOX_Y		  = 30;
	const short CHAT_BOX_HEIGHT	  = 370;
	const short CHAT_BOX_WIDTH	  = 400;

	const short CHAT_ENTRY_X      = 30;
	const short CHAT_ENTRY_Y      = 420;
	const short CHAT_ENTRY_HEIGHT = 30;
	const short CHAT_ENTRY_WIDTH  = 400;
	
	const short CHAT_LOBBY_X	  = 460;
	const short CHAT_LOBBY_Y	  = 30;
	const short CHAT_LOBBY_HEIGHT = 190;
	const short CHAT_LOBBY_WIDTH  = 140;

	const short CHAT_SPACING      = 20;

	const short PLAYER_NAME_X	  = 40;
	const short PLAYER_NAME_Y	  = 460;
	

	//background
	g_pRenderer->DrawRect( 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, CHAT_BACK_COL );

	// main chat box
	g_pRenderer->DrawRect( CHAT_BOX_X, CHAT_BOX_Y, CHAT_BOX_WIDTH+6, CHAT_BOX_HEIGHT+6, CHAT_OUTER_COL );
	g_pRenderer->DrawRect( CHAT_BOX_X, CHAT_BOX_Y, CHAT_BOX_WIDTH,   CHAT_BOX_HEIGHT,   CHAT_INNER_COL );

	// chat entry
	g_pRenderer->DrawRect( CHAT_ENTRY_X, CHAT_ENTRY_Y, CHAT_ENTRY_WIDTH+6, CHAT_ENTRY_HEIGHT+6, CHAT_OUTER_COL );
	g_pRenderer->DrawRect( CHAT_ENTRY_X, CHAT_ENTRY_Y, CHAT_ENTRY_WIDTH,   CHAT_ENTRY_HEIGHT,   CHAT_INNER_COL );

	// chat lobby list
	g_pRenderer->DrawRect( CHAT_LOBBY_X, CHAT_LOBBY_Y, CHAT_LOBBY_WIDTH+6, CHAT_LOBBY_HEIGHT+6, CHAT_OUTER_COL );
	g_pRenderer->DrawRect( CHAT_LOBBY_X, CHAT_LOBBY_Y, CHAT_LOBBY_WIDTH,   CHAT_LOBBY_HEIGHT,   CHAT_INNER_COL );

	// parse old chat
	if ( g_vChatMessages.size() > MAX_TEXT_CHAT_LINES )
	{
		// pop one at a time... may seem silly but this IS being called every frame so
		// it won't be a problem if there are many, many lines of text...
		// plus this distributes the workload (.pop_front()) over a number of frames
		g_vChatMessages.pop_front();
	}

	// display past chat!
	for ( unsigned int i = 0; i < g_vChatMessages.size(); ++i )
	{
		g_pRenderer->DrawString( CHAT_BOX_X+6, CHAT_BOX_Y+6+(CHAT_SPACING*i), g_vChatMessages[i].c_str(), CHAT_BOX_TEXT_COL );																											
	}

	// cursor
	if ( g_userMsgToSend.size() > 0 )
	{
		// something to display
		g_pRenderer->DrawString( CHAT_ENTRY_X+6, CHAT_ENTRY_Y+6, g_userMsgToSend.c_str(), 0xffffffff );
	}
	else
	{
		// quick hack for a blinking cursor
		static int i = 0; ++i;
		if ( sin( i / 22.0f ) > 0 )
			g_pRenderer->DrawString( CHAT_ENTRY_X+6, CHAT_ENTRY_Y+6, "|", 0xffffffff );
	}

	// Draw player's name
	g_pRenderer->DrawString( PLAYER_NAME_X, PLAYER_NAME_Y, g_clientName, 0xffffffff );
	
	// Draw chatroom members
	int x = CHAT_LOBBY_X + 4;
	int y = CHAT_LOBBY_Y + 4;
	for (unsigned int i = 0; i < g_chatroomParticipants.size(); ++i)
	{
		g_pRenderer->DrawString(x, y, g_chatroomParticipants[i].c_str(), CHAT_MEMBER_COL );
		y += CHAT_SPACING;
	}
}

void DrawGameField()
{
	// This draws the client's game field

	// Opponent 1, 2, 3 across the top
	// 
	// 'Player 1'       'Player 2'       'Player 3'
	//   _______         ______           ________  
	//  |     |||       |     ||         |    |||||   // subtle indication of opponent num of cards
	//                                             
	//   Deck    Last Played                                        
	//   _______   _______         
	//  |///////| |       |         
	//  |///////| |       |         
	//  |///////| |   2   |         
	//  |///////| |       |         
	//  |///////| |       |         
	//  |///////| |_______|         
	//                      .------------------------------.
	//                      |                              |
	//                      | Small chat history           |
	//                      |                              |
	//                      |______________________________|
	// 'Client'             ________________________________
	//                      | Chat field                   |
	//                      --------------------------------
	//
	//  You at the bottom

	const unsigned int CHAT_INNER_COL    = 0xff0066CC;
	const unsigned int CHAT_OUTER_COL    = 0xff004488;
	const unsigned int CHAT_BACK_COL     = 0xff222255;
	const unsigned int CHAT_BOX_TEXT_COL = 0xffeeeeff;
	const unsigned int PLAYER_NAME_COL   = 0xffffffff;
	const unsigned int CARD_NUMBER_COL   = 0xff112244;

	const short CHAT_BOX_X		  = 280;
	const short CHAT_BOX_Y		  = 280;
	const short CHAT_BOX_HEIGHT	  = 130;
	const short CHAT_BOX_WIDTH	  = 340;

	const short CHAT_ENTRY_X      = 280;
	const short CHAT_ENTRY_Y      = 430;
	const short CHAT_ENTRY_HEIGHT = 30;
	const short CHAT_ENTRY_WIDTH  = 310;
	
	//const short CARD_SIZE_X        = 100;
	//const short CARD_SIZE_Y        = 140;
	//const short SMALL_CARD_SIZE_X  = 32;
	//const short SMALL_CARD_SIZE_Y  = 45;

	const short PLAYER_NAME_X     = 10;
	const short PLAYER_NAME_Y     = 440;
	
	//const short PLAYER_CARDS_X    = 10;
	//const short PLAYER_CARDS_Y    = 280;

	const short OPPONENT_1_NAME_X = 20;
	const short OPPONENT_1_NAME_Y = 20;
	const short OPPONENT_2_NAME_X = 240;
	const short OPPONENT_2_NAME_Y = 20;
	const short OPPONENT_3_NAME_X = 480;
	const short OPPONENT_3_NAME_Y = 20;

	const short OPPONENT_1_CARDS_X = 20;
	const short OPPONENT_1_CARDS_Y = 40;
	const short OPPONENT_2_CARDS_X = 220;
	const short OPPONENT_2_CARDS_Y = 40;
	const short OPPONENT_3_CARDS_X = 440;
	const short OPPONENT_3_CARDS_Y = 40;

	const short OPPONENT_CARDS_SPREAD = 180 - SMALL_CARD_SIZE_X;

	//const short DECK_X             = 20;
	//const short DECK_Y             = 110;
	const short LAST_CARD_X        = 160;
	const short LAST_CARD_Y        = 110;

	const short CHAT_SPACING       = 20;

	//const short PLY_CARD_COLUMNS   = 7;

	//const short SMALL_CARD_SPACING_X = 3;
	//const short SMALL_CARD_SPACING_Y = 4;

	const short SMALL_CARD_SIZE_X_PLUS_SPC = SMALL_CARD_SIZE_X + SMALL_CARD_SPACING_X;
	const short SMALL_CARD_SIZE_Y_PLUS_SPC = SMALL_CARD_SIZE_Y + SMALL_CARD_SPACING_Y;

	//background
	g_pRenderer->DrawRect( 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, CHAT_BACK_COL );

	// main chat box
	g_pRenderer->DrawRect( CHAT_BOX_X, CHAT_BOX_Y, CHAT_BOX_WIDTH+6, CHAT_BOX_HEIGHT+6, CHAT_OUTER_COL );
	g_pRenderer->DrawRect( CHAT_BOX_X, CHAT_BOX_Y, CHAT_BOX_WIDTH,   CHAT_BOX_HEIGHT,   CHAT_INNER_COL );

	// chat entry
	g_pRenderer->DrawRect( CHAT_ENTRY_X, CHAT_ENTRY_Y, CHAT_ENTRY_WIDTH+6, CHAT_ENTRY_HEIGHT+6, CHAT_OUTER_COL );
	g_pRenderer->DrawRect( CHAT_ENTRY_X, CHAT_ENTRY_Y, CHAT_ENTRY_WIDTH,   CHAT_ENTRY_HEIGHT,   CHAT_INNER_COL );

	// parse old chat
	if ( g_vChatMessages.size() > MAX_TEXT_CHAT_LINES_INGAME )
	{
		g_vChatMessages.pop_front(); // eesh.
	}

	// display past chat!
	for ( unsigned int i = 0; i < g_vChatMessages.size(); ++i )
	{
		g_pRenderer->DrawString( CHAT_BOX_X+6, CHAT_BOX_Y+6+(CHAT_SPACING*i), g_vChatMessages[i].c_str(), CHAT_BOX_TEXT_COL );																											
	}

	// cursor
	if ( g_userMsgToSend.size() > 0 )
	{
		// something to display
		g_pRenderer->DrawString( CHAT_ENTRY_X+6, CHAT_ENTRY_Y+6, g_userMsgToSend.c_str(), 0xffffffff );
	}
	else
	{
		// quick hack for a blinking cursor
		static int i = 0; ++i;
		if ( sin( i / 22.0f ) > 0 )
			g_pRenderer->DrawString( CHAT_ENTRY_X+6, CHAT_ENTRY_Y+6, "|", 0xffffffff );
	}

	// Draw player's name
	g_pRenderer->DrawString( PLAYER_NAME_X, PLAYER_NAME_Y, g_clientName, PLAYER_NAME_COL);
	
	// Draw opponent's names
	g_pRenderer->DrawString( OPPONENT_1_NAME_X, OPPONENT_1_NAME_Y, g_gamePlayers[0].c_str(), PLAYER_NAME_COL );
	g_pRenderer->DrawString( OPPONENT_2_NAME_X, OPPONENT_2_NAME_Y, g_gamePlayers[1].c_str(), PLAYER_NAME_COL );
	g_pRenderer->DrawString( OPPONENT_3_NAME_X, OPPONENT_3_NAME_Y, g_gamePlayers[2].c_str(), PLAYER_NAME_COL );
	
	// Draw Stack and Active Card
	g_pRenderer->DrawSurface( g_pImageBank->GetCardBackImage(), DECK_X, DECK_Y );
	g_pRenderer->DrawSurface( g_pImageBank->GetCardFrontImage(), LAST_CARD_X, LAST_CARD_Y );

	g_pRenderer->DrawString( (unsigned short)(LAST_CARD_X + ( .4 * CARD_SIZE_X )),
							 (unsigned short)(LAST_CARD_Y + ( .4 * CARD_SIZE_Y )),
							 g_activeCard.GetReadableShort().c_str(), CARD_NUMBER_COL );
	
	// Draw all players cards
	short xOffset, yOffset, iter = 0;

	// draw player's cards
	std::vector<NPCard>::iterator cardPtr;
	for ( cardPtr = g_gameCards.begin(); cardPtr != g_gameCards.end(); ++cardPtr )
	{
		//draw a card, then draw a string over it.
		xOffset = 0;
		yOffset = 0;

		g_pRenderer->DrawSurface( g_pImageBank->GetCardFrontSmallImage(),
					 PLAYER_CARDS_X + ( ( (short)(iter%PLY_CARD_COLUMNS) ) * SMALL_CARD_SIZE_X_PLUS_SPC ),
					 PLAYER_CARDS_Y + ( ( (short)(iter/PLY_CARD_COLUMNS) ) * SMALL_CARD_SIZE_Y_PLUS_SPC ) );

		g_pRenderer->DrawString(
				PLAYER_CARDS_X + ( ( (short)(iter%PLY_CARD_COLUMNS) ) * SMALL_CARD_SIZE_X_PLUS_SPC )
										                         + ( (short)( .4 * SMALL_CARD_SIZE_X ) ),
				PLAYER_CARDS_Y + ( ( (short)(iter/PLY_CARD_COLUMNS) ) * SMALL_CARD_SIZE_Y_PLUS_SPC ) 
										                         + ( (short)( .4 * SMALL_CARD_SIZE_Y ) ),
								 (*cardPtr).GetReadableShort().c_str(),
								 CARD_NUMBER_COL );
	
		iter++;
	}

	// Draw opponents cards (face down)
	
	for ( int i = 1; i <= g_gameOppCards[0]; ++i )
		g_pRenderer->DrawSurface( g_pImageBank->GetCardBackSmallImage(),
								  OPPONENT_1_CARDS_X + ( OPPONENT_CARDS_SPREAD / g_gameOppCards[0] ) * i,
								  OPPONENT_1_CARDS_Y );

	for ( int i = 1; i <= g_gameOppCards[1]; ++i )
		g_pRenderer->DrawSurface( g_pImageBank->GetCardBackSmallImage(),
								  OPPONENT_2_CARDS_X + ( OPPONENT_CARDS_SPREAD / g_gameOppCards[1] ) * i,
								  OPPONENT_2_CARDS_Y );

	for ( int i = 1; i <= g_gameOppCards[2]; ++i )
		g_pRenderer->DrawSurface( g_pImageBank->GetCardBackSmallImage(),
								  OPPONENT_3_CARDS_X + ( OPPONENT_CARDS_SPREAD / g_gameOppCards[2] ) * i,
								  OPPONENT_3_CARDS_Y );

	if ( g_myTurn )
	{
		g_pRenderer->DrawString( 70, 450, "It's your turn!", 0xffff00ff );
	}
}

void init( char* serverAddress, unsigned short localPort )
{
	// seed random
	srand((int)time(0));

	// initialize SDL
	g_pRenderer = new SDLRenderer();
	if ( g_pRenderer->Init( SCREEN_WIDTH, SCREEN_HEIGHT, FONT_PATH ) == -1 )
		exit(1);

	// initialize SDL_net
	if( SDLNet_Init() == -1 )
	{
		printf( "SDLNet_Init: %s\n",SDLNet_GetError() );
		exit(2);
	}

	// Register SDL_Quit to be called at exit; makes sure things are
	// cleaned up when we quit.
	atexit(SDL_Quit);

	// Init SDL_image...
	g_pImageBank = new NPImageBank();

	// Init client name
	sprintf_s( g_clientName, sizeof( DEFAULT_CLIENT_NAME )+3, "%s%03d", DEFAULT_CLIENT_NAME, NPHelper::GetRand(0, 999) );

	// Init Network Thread
	char tempIName[127];
	sprintf_s(tempIName, 127, "Interface %s", g_clientName );

	g_pNetworkInterface = new NPNetworkInterface( tempIName, g_multClients );
	g_pNetworkInterface->InitializeClient( serverAddress, 
										   DEFAULT_SERVER_PORT,
										   localPort );

	// Init game state
	g_currentGameState = GAMESTATE_CHAT;

	// Init Misc
	SDL_EnableUNICODE(1);
	
	g_lastServerPing = 0;
	g_waitingPingResponse = false;
}

int update()
{
	// process or receive any messages
	static int i; i++;
	if ( i % 10 == 0 )
	{
		NPNetMessage newMsg = g_pNetworkInterface->GetNextMessage(false);
		if ( newMsg.GetDataSize() > 0 )
		{
			switch ( newMsg.GetMessageType() )
			{
				case MSG_CHAT_MESSAGE:
				{
					g_vChatMessages.push_back( newMsg.GetData() );
					break;
				}
				case MSG_NAME_REQUEST:
				{
					// server wants to know our name!
					NPNetMessage newMsg( g_pNetworkInterface->GetLocalIPAddress(),
										 g_pNetworkInterface->GetRemoteIPAddress(),
										 std::string(g_clientName),
										 MSG_NAME_UPDATE );

					g_pNetworkInterface->AddNewMessage( newMsg, true );
					break;
				}
				case MSG_NAME_UPDATE:
				{
					assert(0);
					break;
				}
				case MSG_CHAT_PARTICIPANTS_LIST:
				{
					// server has sent us a list of the names of all the people in the chatroom
					g_chatroomParticipants.clear();
					std::vector<std::string> participants = NPHelper::ParseCSV( newMsg.GetTextData() );

					for ( unsigned int i = 0; i < participants.size(); ++i )
						g_chatroomParticipants.push_back( participants.at(i) );

					break;
				}
				case MSG_PING:
				{
					g_pNetworkInterface->AddNewMessage( NPNetMessage( g_pNetworkInterface->GetLocalIPAddress(),
																	  g_pNetworkInterface->GetRemoteIPAddress(),
																	  "PONG",
																	  MSG_PONG ), true );
					printf("%s: PING received - request!\n", g_clientName);
					break;
				}
				case MSG_PONG:
				{
					g_lastServerPing = time(0);
					printf("%s: PONG recieved - response!\n", g_clientName);
					g_waitingPingResponse = false;
					g_pNetworkInterface->SuccessfulPing();
					break;
				}
				case MSG_START_GAME:
				{
					// Initialize a new game :)
					// The following is happening:
					// The server has sent us an OK to go ahead and start a game
					// The server has set up the game
					// We must now transfer to the Game-playing state
					// We must extract all useful data from the initialization message
					// This will be (IN THIS ORDER):
					// ("gamehash", "PLAYERS_CARDS_STR", "STACK_CARD" "OPP1_NUMCARDS", "OPP2_NUMCARDS", "OPP3_NUMCARDS", "MYTURN?", "OPP1_NAME", "OPP2_NAME", "OPP3_NAME")
					// i.e. ( "1075913", "1124558", "8", "2", "3", "5", "0", "Bob", "Alice", "Henry" )
					// We are then done :)

					g_gameCards.clear();
					g_gameHash = 0;
					g_gameOppCards[0] = 0;
					g_gameOppCards[1] = 0;
					g_gameOppCards[2] = 0;
					g_gamePlayers[0] = "";
					g_gamePlayers[1] = "";
					g_gamePlayers[2] = "";
					g_myTurn = false;

					g_activeCard = NPCard( NPCARDTYPE_NULL, 0 );
					g_currentGameState = GAMESTATE_INGAME;

					std::vector<std::string> dataParsed = NPHelper::ParseCSV( newMsg.GetData() );
					assert( dataParsed.size() == 10 );
					g_gameHash = atoi( dataParsed[0].c_str() );

					// data will be csv c-strings (NB. Must end with comma as well!)
					// loop through data, parse into strings

					for ( unsigned short i = 0; i < dataParsed[1].size(); ++i )
					{
						// player's cards
						short value = dataParsed[1][i] - 48; // ASCII hack! ASCII numerics start at 48

						g_gameCards.push_back( NPCard( NPCARDTYPE_NORMAL, value ) );
					}

					// refresh active card
					g_activeCard = NPCard(NPCARDTYPE_NORMAL, atoi( dataParsed[2].c_str() ) );

					// number of cards for each opponent
					g_gameOppCards[0] = atoi( dataParsed[3].c_str() );
					g_gameOppCards[1] = atoi( dataParsed[4].c_str() );
					g_gameOppCards[2] = atoi( dataParsed[5].c_str() );

					// is it my go? ( 0 or 1 )
					g_myTurn = dataParsed[6] == "1" ? true : false;

					g_gamePlayers[0] = dataParsed[7];
					g_gamePlayers[1] = dataParsed[8];
					g_gamePlayers[2] = dataParsed[9];

					printf("\n *** MSG_GAME_START HANDLED! ***\n" );
					break;
				}
				case MSG_GAME_UPDATE:
				{
	// "gamehash", "PLAYERS_CARDS_STR", "STACK_CARD" "OPP1_NUMCARDS", "OPP2_NUMCARDS", "OPP3_NUMCARDS", "MYTURN?"
					// i.e. ( "1075913", "1124558", "8", "2", "3", "5", "0", )

					// data will be csv c-strings (NB. Must end with comma as well!)
					// loop through data, parse into strings

					std::vector<std::string> dataParsed = NPHelper::ParseCSV( newMsg.GetData() );

					// ensure that the server is asking to manage the same game as the one we started
					assert( atoi( dataParsed[0].c_str() ) == g_gameHash );

					// forget everything you know, refresh card knowledge
					g_gameCards.clear();

					for ( unsigned short i = 0; i < dataParsed[1].size(); ++i )
					{
						// player's cards
						short value = dataParsed[1][i] - 48; // ASCII hack! ASCII numerics start at 48

						g_gameCards.push_back( NPCard( NPCARDTYPE_NORMAL, value ) );
					}

					// refresh active card
					g_activeCard = NPCard(NPCARDTYPE_NORMAL, atoi( dataParsed[2].c_str() ) );

					// number of cards for each opponent
					g_gameOppCards[0] = atoi( dataParsed[3].c_str() );
					g_gameOppCards[1] = atoi( dataParsed[4].c_str() );
					g_gameOppCards[2] = atoi( dataParsed[5].c_str() );

					// is it my go? ( 0 or 1 )
					g_myTurn = ( dataParsed[6] == "1" ? true : false );

					printf("\n *** MSG_GAME_UPDATE HANDLED! ***\n" );
					break;
				}
				default:
				{
					printf( "%s: *** Unhandled Message Rcvd! *** *URGENT*\n", g_clientName );
					break;
				}
			}
		}
	}
	
	// process all state-related updates
	switch ( g_currentGameState )
	{
	case GAMESTATE_CHAT:
		break;
	case GAMESTATE_INGAME:
		// big! Game goes here!
		break;
	}

	// suggest pinging
	time_t now;
	time(&now);
	long since = (long)(now - g_lastServerPing);
	if ( !g_waitingPingResponse && since > 10 )
	{
		g_pNetworkInterface->AddNewMessage(NPNetMessage( g_pNetworkInterface->GetLocalIPAddress(),
														 g_pNetworkInterface->GetRemoteIPAddress(),
														 "PING",
														 MSG_PING ), true );
		g_lastServerPing = now;
		g_waitingPingResponse = true;
		
	}

	if ( g_waitingPingResponse && since > 100 )
	{
		// drop the request, it's been ages - another ping will get sent
		g_waitingPingResponse = false;
	}

	return 0;
}

int render()
{   
	g_pRenderer->StartDrawing();
	{
		switch ( g_currentGameState )
		{
		case GAMESTATE_NONE:
#ifdef _DEBUG
			g_pRenderer->DrawString( 3, 3, "GameState_None", 0xff00ffff );
#endif //_DEBUG
			//unknown?
			break;
		case GAMESTATE_CHAT:
		case GAMESTATE_CHAT_ATTEMPT_TO_SEND:
		case GAMESTATE_CHAT_ATTEMPT_TO_RCV:
			DrawChatField();
#ifdef _DEBUG
			g_pRenderer->DrawString( 3, 3, "GameState_Chat", 0xff00ff00 );
#endif //_DEBUG
			//display chat field
			break;
		case GAMESTATE_INGAME:
			DrawGameField();
#ifdef _DEBUG
			g_pRenderer->DrawString( 3, 3, "GameState_Ingame", 0xff0000ff );
#endif //_DEBUG
			//display game
			break;
		case GAMESTATE_BUSY:
#ifdef _DEBUG
			g_pRenderer->DrawString( 3, 3, "GameState_Busy", 0xffff0000 );
#endif //_DEBUG
			//display chat but maintain busy status
			break;
		default:
			assert(0); // must handle all gamestates!
			break;
		}

		// no matter what the gamestate, display the server connection status in BR corner
		bool hasConnectionToServer = g_pNetworkInterface->HasRemoteConnection();
		//bool hasConnectionToServer = true;

		SDL_Surface* connImg = g_pImageBank->GetConnectionStatusImage( hasConnectionToServer );
		g_pRenderer->DrawSurface( connImg, 600, 440 );

		time_t rawTime = 0;
		time( &rawTime );
		struct tm now;
		localtime_s( &now, &rawTime );

		char theTime[50];
		strftime( theTime, 50, "%H:%M:%S", &now );

		g_pRenderer->DrawString( 280, 3, theTime, 0xddccccff );

#ifdef _DEBUG
		// Display mouse state

		int x, y;
		SDL_GetMouseState( &x, &y );
		char mouseState[30];
		sprintf_s( mouseState, 30, "x: %d, y: %d", x, y );
		g_pRenderer->DrawString( 500, 4, mouseState, 0xffffffff );
#endif // _DEBUG
	}
	g_pRenderer->EndDrawing();

	return 0;
}

#ifdef _DEBUG
bool UnitTestGame()
{
	// This just tests updating the player's perspective on the game
	// giving the player's own cards, and the opponent card counts
	g_gameCards.push_back(NPCard(NPCARDTYPE_NORMAL, 1));
	g_gameCards.push_back(NPCard(NPCARDTYPE_NORMAL, 2));
	g_gameCards.push_back(NPCard(NPCARDTYPE_NORMAL, 3));
	g_gameCards.push_back(NPCard(NPCARDTYPE_NORMAL, 4));
	g_gameCards.push_back(NPCard(NPCARDTYPE_NORMAL, 5));
	g_gameCards.push_back(NPCard(NPCARDTYPE_NORMAL, 6));
	g_gameCards.push_back(NPCard(NPCARDTYPE_NORMAL, 7));
	g_gameCards.push_back(NPCard(NPCARDTYPE_NORMAL, 8));
	g_gameCards.push_back(NPCard(NPCARDTYPE_NORMAL, 9));

	g_gameOppCards[0] = 6;
	g_gameOppCards[1] = 7;
	g_gameOppCards[2] = 8;

	return true;
}

#endif // _DEBUG
// Entry point
int main(int argc, char *argv[])
{
	char* m_serverAddress = DEFAULT_SERVER_ADDRESS;
	unsigned short m_localPort = DEFAULT_LOCAL_PORT;

	// allow for command line arguments
	if ( argc > 1 )
		g_multClients = true; //if any cmd line arg is passed, assume mult clients at localhost
	//	m_serverAddress = argv[1];

	init( m_serverAddress, m_localPort );

	g_vChatMessages.push_back(" Welcome to Scott's NP Card Game Client. ");
	g_vChatMessages.push_back(" Type \\help for help. ");

#ifdef _DEBUG
	UnitTestGame();
#endif

	// Main loop: loop forever.
	while (1)
	{
		static int gameLoop = 0; gameLoop++;
		if ( gameLoop % 500 == 0 )
			printf("%s: Gameloop[%i]\n", g_clientName, gameLoop);

		// Update
		if ( update() == -1 ) return (1);

		// Render
		if ( render() == -1 ) return (2);

		// Poll for events, and handle the ones we care about
		SDL_Event event;
		while ( SDL_PollEvent(&event) ) 
		{
			switch (event.type)
			{
			case SDL_KEYDOWN:
				// If escape is pressed, return (and thus, quit)
				
				// These affect ALL STATES
				if (event.key.keysym.sym == SDLK_ESCAPE)
					return 0;
#ifdef _DEBUG
				if (event.key.keysym.sym == SDLK_F1)
					g_currentGameState = GAMESTATE_CHAT;
				if (event.key.keysym.sym == SDLK_F2)
					g_currentGameState = GAMESTATE_BUSY;
				if (event.key.keysym.sym == SDLK_F3)
					g_currentGameState = GAMESTATE_INGAME;
				if (event.key.keysym.sym == SDLK_F4)
					g_currentGameState = GAMESTATE_NONE;
#endif //_DEBUG
			
				switch ( g_currentGameState )
				{
				case GAMESTATE_INGAME:
				case GAMESTATE_CHAT:
					{
						// keys entered when you are chatting
						char keyInput = (char)event.key.keysym.unicode;

						// if this keypress was not a 'logical' entry (ascii) ignore it
						if ( keyInput == 0 ) break;

						// check symbols first
						int i = 0;
						while ( i != sizeof(symbolsOKtoSend)-1 )
						{
							// compare against all 'safe' symbols defined earlier
							if ( keyInput == symbolsOKtoSend[i] )
							{
								g_userMsgToSend += keyInput;
								break;
							}
							++i;
						}

						if( keyInput == (Uint16)' ' )
						{
							g_userMsgToSend += (char)event.key.keysym.unicode;
						} 
						else if( ( keyInput >= (Uint16)'0' ) && ( keyInput <= (Uint16)'9' ) )
						{
							g_userMsgToSend += (char)event.key.keysym.unicode;
						}
						else if( ( keyInput >= (Uint16)'A' ) && ( keyInput <= (Uint16)'Z' ) )
						{
							g_userMsgToSend += (char)event.key.keysym.unicode;
						}
						else if( ( keyInput >= (Uint16)'a' ) && ( keyInput <= (Uint16)'z' ) )
						{
							g_userMsgToSend += (char)event.key.keysym.unicode;
						}

						//If backspace was pressed
						if( ( event.key.keysym.sym == SDLK_BACKSPACE ) && ( g_userMsgToSend.length() != 0 ) )
						{
							g_userMsgToSend.erase( g_userMsgToSend.length() - 1 );
						}

						// If return was pressed
						if ( ( event.key.keysym.sym == SDLK_RETURN ) && ( g_userMsgToSend.length() != 0 ) )
						{
							// send new message!
							if ( !DoChatCommand() )
							{
								std::string finalMsgToSend = std::string(g_clientName) + ": " + g_userMsgToSend;

								NPNetMessage newMessage( g_pNetworkInterface->GetLocalIPAddress(),
														 g_pNetworkInterface->GetRemoteIPAddress(),
														 finalMsgToSend,
														 MSG_CHAT_MESSAGE);

								g_pNetworkInterface->AddNewMessage( newMessage, true );

								// return to normal state
								g_userMsgToSend.clear();
							}
						}

						break;
					}
				}
				
				break;
			case SDL_KEYUP:
				break;
			case SDL_QUIT:
				return(0);
			case SDL_MOUSEBUTTONDOWN:
				// click! process this in all cases.

				int x = 0; int y = 0; unsigned short cardIndex = 0;
				SDL_GetMouseState( &x, &y );
				CLICK_MSG_RETURN clickType = ProcessClick( x, y, cardIndex );

				switch ( clickType )
				{
				case CLICK_NULL:
					// do nothing
					break;
				case CLICK_CARD_DECK:
					//legally clicked on the deck
					if ( g_myTurn )
					{
						g_pNetworkInterface->AddNewMessage( NPNetMessage(g_pNetworkInterface->GetLocalIPAddress(),
																		 g_pNetworkInterface->GetRemoteIPAddress(),
																		 -1,
																		 MSG_GAME_PROCESS_MOVE ), true );
						printf("%s: CLICK: clicked on Deck - request 2 cards!\n", g_clientName );
					}
					break;
				case CLICK_CARD_STANDARD:
					{
						if ( g_myTurn && ( cardIndex <= g_gameCards.size() ) )
						{
							// legal click - process it!
							g_pNetworkInterface->AddNewMessage( NPNetMessage(g_pNetworkInterface->GetLocalIPAddress(),
																			 g_pNetworkInterface->GetRemoteIPAddress(),
																			 cardIndex,
																			 MSG_GAME_PROCESS_MOVE ), true );

							printf("%s: CLICK: clicked on Card (value %u)!\n", g_clientName,
															g_gameCards.at(cardIndex).GetValue() );
						}
					}
					break;
				case CLICK_HELP:
					assert(0); // not impl
					break;
				default:
					break;
				}

				break;
			}
		}
	
		SDL_Delay(10); // for the processor to catch up
	}
	return 0;
}
