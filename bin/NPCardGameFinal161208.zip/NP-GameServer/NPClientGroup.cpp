#include "NPClientGroup.h"
#include "NPClientID.h"
#include "../NP-Shared/NPHelper.h"

///////////////////////////////////////////////////////////////////
// NPClientGroup                                                 //
// This class represents a collection of clients (NPClientID's)  //
// and also provides functionality to manage each client.        //
///////////////////////////////////////////////////////////////////


NPClientGroup::NPClientGroup(void)
{
}

NPClientGroup::~NPClientGroup(void)
{
}

bool NPClientGroup::UpdateClientName( unsigned int hash, std::string newName )
{
	std::vector<NPClientID>::iterator iter;

	for ( iter = m_clients.begin(); iter != m_clients.end(); ++iter )
	{
		if ( (*iter).Hash() == hash )
		{
			(*iter).SetName(newName);
			return true;
		}
	}

	return false;
}

bool NPClientGroup::CreateClient( IPaddress src, unsigned int hash, std::string name, bool multClients )
{
	// returns true if it can create a new client,

	m_clients.push_back( NPClientID( hash, src, name, multClients ) );
	return true;
}

unsigned short NPClientGroup::GetNumClientsConnected()
{
	return m_clients.size();
}
bool NPClientGroup::UpdateClientConnectionStatus( unsigned int clientHash, bool goodMsg )
{
	// if the client has dropped a message, or cannot receive it
	// goodMsg == false, and therefore m_connectionStatus -= 1
	// if this drops below 0, the client drops

	std::vector<NPClientID>::iterator iter;

	for ( iter = m_clients.begin(); iter != m_clients.end(); ++iter )
	{
		if ( (*iter).Hash() == clientHash )
		{
			if ( goodMsg )
			{
				// good message recv'd
				(*iter).m_connectionStatus++;
				if ( (*iter).m_connectionStatus > 100 )
					(*iter).m_connectionStatus = 100;
				return true;
			}
			else
			{
				(*iter).m_connectionStatus--;
				if ( (*iter).m_connectionStatus < 0 )
				{
					//drop client
					m_clients.erase(iter);
					return true;
				}
			}
		}
	}

	return false;
}

NPClientID NPClientGroup::GetClientFromHash( unsigned int hash )
{
	std::vector<NPClientID>::iterator iter;
	for ( iter = m_clients.begin(); iter != m_clients.end(); ++iter )
	{
		if ( (*iter).Hash() == hash )
			return (*iter);
	}
	return NPClientID();
}

bool NPClientGroup::DoesClientHashExist( unsigned int hash )
{
	std::vector<NPClientID>::iterator iter;
	for ( iter = m_clients.begin(); iter != m_clients.end(); ++iter )
	{
		if ( (*iter).Hash() == hash )
			return true;
	}
	return false;
}

std::string NPClientGroup::GetClientName( unsigned int hash )
{
	std::vector<NPClientID>::iterator iter;
	for ( iter = m_clients.begin(); iter != m_clients.end(); ++iter )
	{
		if ( (*iter).Hash() == hash )
			return (*iter).GetName();
	}
	return false;
}

std::vector<std::string> NPClientGroup::GetAllClientNames()
{
	std::vector<std::string> retVal;

	std::vector<NPClientID>::iterator iter;
	for ( iter = m_clients.begin(); iter != m_clients.end(); ++iter )
	{
		retVal.push_back( (*iter).GetName() );
	}
	
	return retVal;
}

bool NPClientGroup::RemoveClient( IPaddress src )
{
	std::vector<NPClientID>::iterator iter;
	for ( iter = m_clients.begin(); iter != m_clients.end(); ++iter )
	{
		if ( (*iter).GetAddress().host == src.host && 
			 (*iter).GetAddress().port == src.port)
		{
			m_clients.erase(iter);
			return true;
		}
			
	}
	return false;
}
bool NPClientGroup::RemoveClient( unsigned int hash )
{
	std::vector<NPClientID>::iterator iter;
	for ( iter = m_clients.begin(); iter != m_clients.end(); ++iter )
	{
		if ( (*iter).Hash() == hash )
		{
			m_clients.erase(iter);
			return true;
		}
	}
	return false;
}
void NPClientGroup::DumpAll()
{
	std::vector<NPClientID>::iterator iter;
	for ( iter = m_clients.begin(); iter != m_clients.end(); ++iter )
	{
		char ipAddr[30];
		NPHelper::GetReadableIPAddress( (*iter).GetAddress(), ipAddr, true );

		printf( " * \n" );
		printf( " Client Name: %s ", (*iter).GetName().c_str() );
		printf( " Client Hash: %x\n", (*iter).Hash() );
		printf( " Client Address: %s\n", ipAddr );
		printf( " Client Connection Quality: %d\n", (*iter).m_connectionStatus );
		printf( " Client Player ID: %d\n", ( (*iter).m_playerID ) );
		printf( "\n" );
	}
}