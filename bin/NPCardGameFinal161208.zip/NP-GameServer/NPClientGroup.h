#pragma once
#include "SDL_net.h"
#include <vector>

class NPClientID;

class NPClientGroup
{
public:
	NPClientGroup(void);
	~NPClientGroup(void);
public:
	bool DoesClientHashExist( unsigned int hash );
	NPClientID GetClientFromHash( unsigned int hash );
	unsigned short GetNumClientsConnected();

	bool CreateClient( IPaddress src, unsigned int hash, std::string name, bool multClients );
	bool RemoveClient( IPaddress src );
	bool RemoveClient( unsigned int hash );

	bool UpdateClientName( unsigned int hash, std::string newName );
	bool UpdateClientConnectionStatus( unsigned int clientHash, bool goodMsg );

	std::string GetClientName( unsigned int hash );

	std::vector<NPClientID> GetAllClients() { return m_clients; }
	std::vector<std::string> GetAllClientNames();

	void DumpAll();

private:
	std::vector<NPClientID> m_clients;
};
