#include "SDL_net.h"
#include "NPClientID.h"

#include "../NP-Shared/NPNetworkInterface.h"

///////////////////////////////////////////////////////////////////
// NPClientID                                                    //
// This class represents a unique hashed client, used by the     //
// Server for the lobby and the NPGame class to handle clients.  //
///////////////////////////////////////////////////////////////////

NPClientID::NPClientID( unsigned int hash, IPaddress address, std::string name, bool multClients )
{
	m_hash = hash;
	unsigned short tgtPort = CLIENT_LISTEN_PORT;

	if ( multClients )
	{
		// Hack :( this is to allow the server to recognize multiple clients 
		//  from the same IP, so long as clients are created and connect sequentially
		static int clientsCreated = 0;
		tgtPort = CLIENT_LISTEN_PORT + clientsCreated;
		clientsCreated++;
	}

	m_address.host = address.host;
	m_address.port = SDLNet_Read16( &tgtPort );

	m_name = name;
	m_connectionStatus = 100;
	m_playerID = -1;
}

NPClientID::~NPClientID(void)
{
}

bool NPClientID::SetName(std::string newName)
{
	m_name = newName;
	return true;
}