#pragma once

#include "SDL_net.h"
#include <string>

class NPClientID
{
public:
	NPClientID(void) {};
	NPClientID( unsigned int hash, IPaddress address, std::string name, bool multClients );
	~NPClientID(void);

public:
	bool SetName(std::string newName);
	unsigned int Hash() { return m_hash; }
	std::string GetName() { return m_name; }
	IPaddress GetAddress() { return m_address; }

private:
	unsigned int m_hash;		// 
	IPaddress m_address;		//  
	std::string m_name;			// 

public:
	int m_connectionStatus;		// unused
	int m_playerID;				// -1 if not playing 
};