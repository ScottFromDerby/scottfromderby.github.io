#include "NPGame.h"
#include "../NP-Shared/NPCard.h"
#include "../NP-Shared/NPHelper.h"

#include <assert.h>
#include <time.h>

////////////////////////////////////////////////////////////////////
// NPGame                                                         //
// This class contains all the information for a single card game //
// and all the controlling mechanisms to manage updates, logical  //
// states (win/loss/legal move/dealing/shuffling/etc)             //
////////////////////////////////////////////////////////////////////

NPGame::NPGame(std::string name, std::vector<NPClientID> players) : m_name(name), m_hash((int)time(0)+10000)
{
	for ( unsigned int i = 0; i < players.size(); ++i )
	{
		NPPlayerHand newPlayer;
		newPlayer.m_player = players[i];
		newPlayer.m_playing = true;
		m_hands.push_back( newPlayer );
	}
	
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 1 ) );
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 1 ) );
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 1 ) );
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 1 ) );
	
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 2 ) );
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 2 ) );
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 2 ) );
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 2 ) );
	
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 3 ) );
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 3 ) );
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 3 ) );
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 3 ) );
	
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 4 ) );
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 4 ) );
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 4 ) );
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 4 ) );
	
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 5 ) );
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 5 ) );
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 5 ) );
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 5 ) );
	
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 6 ) );
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 6 ) );
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 6 ) );
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 6 ) );
	
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 7 ) );
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 7 ) );
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 7 ) );
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 7 ) );
	
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 8 ) );
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 8 ) );
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 8 ) );
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 8 ) );
	
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 9 ) );
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 9 ) );
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 9 ) );
	m_cards.push_back( new NPCard( NPCARDTYPE_NORMAL, 9 ) );

	m_totalCards = m_cards.size();

	m_whoseTurn = 0;
}

NPGame::~NPGame(void)
{
	// This memory we have managed has dispersed - we need to ensure all those
	// 'new's we made are deleted, wherever they are now!

	unsigned short i;
	for ( i = 0; i < m_hands.size(); ++i )
	{
		for ( unsigned short j = 0; j < m_hands.at(i).m_cards.size(); ++j )
		{
			if ( m_hands.at(i).m_cards.at(j) )
			{
				delete ( m_hands.at(i).m_cards.at(j) );
			}
		}
	}

	for ( i = 0; i < m_cards.size(); ++i )
	{
		delete m_cards[i];
	}
}

void NPGame::Shuffle()
{
	for ( int i = 0; i < 1000; ++i )
	{
		short card1 = NPHelper::GetRand( 0, 35 );
		short card2 = NPHelper::GetRand( 0, 35 );

		NPCard* temp = m_cards[card1];
		m_cards[card1] = m_cards[card2];
		m_cards[card2] = temp;
	}

	printf("%s: Cards shuffled!\n", m_name.c_str() );
}
#ifdef _DEBUG
void NPGame::DumpAllInfo()
{
	printf( "\n * Printing all cards...\n\n * Stack:\n" );

	std::deque<NPCard*>::iterator iter;
	for ( iter = m_cards.begin(); iter != m_cards.end(); ++iter )
	{
		printf ( "    %s\n", (*iter)->GetReadable().c_str() );
	}

	printf( " * Players:\n" );
	for ( unsigned int i = 0; i < m_hands.size(); ++i )
	{
		printf( " Player %u: %s (hash %x)\n",
								i,
								m_hands.at(i).m_player.GetName().c_str(),
								m_hands.at(i).m_player.Hash() );
		if ( m_hands.at(i).m_cards.size() > 0 )
		{
			printf( " * %u: \n", i );
			std::vector<NPCard*>::iterator iter;
			for ( iter = m_hands[i].m_cards.begin(); iter != m_hands.at(i).m_cards.end(); ++iter )
			{
				printf ( "    %s\n", (*iter)->GetReadable().c_str() );
			}
		}
	}
	
	printf("\n");
}
#endif //_DEBUG

void NPGame::Deal(const unsigned short numPlayers)
{
	for (int i = 0; i < numPlayers; ++i )
	{
		for (int j = 0; j < NUM_CARDS_START; ++j )
		{
			// take a card from the TOP of the pile (m_cards)
			m_hands[i].m_cards.push_back( m_cards.front() );
			m_cards.pop_front();
		}
	}
	printf("%s: Cards dealt! %u players.\n", m_name.c_str(), numPlayers );
}

bool NPGame::ProcessTurn( unsigned int playerHash, short whichCard )
{
	// Test this player exists in the current game

	bool found = false;
	short playerIndex = -1;
	for ( unsigned int i = 0; i < m_hands.size(); ++i )
	{
		if ( playerHash == m_hands.at(i).m_player.Hash() )
		{
			found = true;
			playerIndex = i;
		}
	}
	if ( !found )
	{
		printf("Player %s is not in this game!", playerHash );
		return false;
	}

	// Test that it is currently this player's turn!
	
	unsigned int currentHash = 0;
	WhoseTurn(currentHash);

	if ( currentHash != playerHash )
	{
		printf("%s: It is not that player's turn! (Currently %x should play, %x is trying to play", 
																m_name.c_str(), currentHash, playerHash );
		return false;
	}

	// playerHash is the current player, they would like to use their card at index 'whichCard'
	 //ensure this makes sense
	assert( whichCard < (short)m_hands[playerIndex].m_cards.size() );

	if ( whichCard == -1 )
	{
		// player cannot go - or chose to pick up 2
		PickUpCard( playerIndex, NP_PICK_UP_CARDS_AMOUNT );
		//return true; // picking up cards IS the turn - continue to cycle turn order!
	}
	else
	{
		// process turn
		if ( !PutDownCard( playerIndex, whichCard ) )
		{
			// illogical move - do not allow!
			return false;
		}
	}

	// advance turn
	m_whoseTurn++;
	
	// if there is a 'non-player', we can skip past them
	int i = 0;
	while ( i < 4 )
	{
		if ( m_whoseTurn == (short)m_hands.size() )
			m_whoseTurn = 0;

		if ( m_hands[m_whoseTurn].m_playing == false )
		{
			m_whoseTurn++;
		}
		else
		{
			break;
		}
	}

	//from here, NPGameServer should update all players with correct move
	return true;
}

unsigned short NPGame::WhoseTurn( unsigned int& hash )
{
	// return the index of whose turn it is
	// arg 'hash' is a reference unsigned int to the current player, which gets filled in 

	hash = m_hands[m_whoseTurn].m_player.Hash();
	return m_whoseTurn;
}

unsigned short NPGame::WhoseTurn()
{
	// return the index of whose turn it is

	return m_whoseTurn;
}

bool NPGame::IsLogicalMove( NPCard* toPlay )
{
	// logical comparison - adjust as rules dictate

	// comparison between m_cards.front() and toPlay
	if ( toPlay->GetValue() >= GetTopCard()->GetValue() ||
		toPlay->GetValue() == 1 )
	{
		return true;
	}
	else
	{
		return false;
	}

}

std::string NPGame::GetGameState( unsigned short whichPlayer )
{
	std::string retVal("NOTIMPL!");
	
	return retVal;
}

bool NPGame::PickUpCard( unsigned short whichPlayer, unsigned short howMany )
{
	// handles the logic of picking up a card from the pile
	for ( int i = 0; i < howMany; ++i )
	{
		if ( m_cards.size() > 0 )
		{
			m_hands[whichPlayer].m_cards.push_back( m_cards.front() );
			m_cards.pop_front();
		}
		else
		{
			// not enough cards left to pick up any!
			printf("%s: Player %u cannot pick up any cards, non remain!\n", m_name.c_str(), whichPlayer);
			return true; // logical 'OK' here
		}
	}

	return true;
}

bool NPGame::PutDownCard( unsigned short whichPlayer, unsigned short whichCard )
{
	assert( whichCard != -1 );

	// handles the logic of placing a card to the top of the pile
	if ( IsLogicalMove( m_hands[whichPlayer].m_cards[whichCard] ) )
	{
		m_cards.push_front( m_hands[whichPlayer].m_cards[whichCard] );
		m_hands[whichPlayer].m_cards.erase( m_hands[whichPlayer].m_cards.begin()+whichCard );
		return true;
	}
	else
	{
		// illegal move...
		printf("%s: Player %u is attempting to play %s - this is an illegal move!\n", m_name.c_str(), whichPlayer,
												m_hands[whichPlayer].m_cards[whichCard]->GetReadable().c_str() );
		return false;
	}
}

std::string NPGame::GetHand( unsigned short whichPlayer )
{
	// returns a string of characters, where a character represents a card
	// cards are represented by a numeric (value) of 1-9, or... (future implementation?)
	std::string retVal;
	std::vector<NPCard*>::iterator iter;
	for ( iter = m_hands[whichPlayer].m_cards.begin(); iter != m_hands[whichPlayer].m_cards.end(); ++iter )
	{
		char temp[4]; // just in case!
		sprintf_s( temp, 4, "%u", (*iter)->GetValue() );
		retVal += temp;
	}
	
	return retVal;
}

unsigned short NPGame::GetPlayerID( unsigned int hash )
{
	// does this game contain the player identified by this hash?
	// if not, return -1
	// if so, return the player ID (0-4)

	for (unsigned int i = 0; i < m_hands.size(); ++i )
	{
		if ( m_hands.at(i).m_player.Hash() == hash )
		{
			return i;
		}
	}
	return -1;
}

NPClientID NPGame::GetParticipantFromHash( unsigned int hash )
{
	for (unsigned int i = 0; i < m_hands.size(); ++i )
	{
		if ( m_hands.at(i).m_player.Hash() == hash )
		{
			return m_hands.at(i).m_player;
		}
	}
	return NPClientID();
}

unsigned short NPGame::HasAnyoneWon()
{
	unsigned short retVal = 0;
	for ( int i = 0; i < 4; ++i )
	{
		if ( m_hands.at(i).m_cards.size() == 0 )
			retVal = i;
	}

	return retVal;
}

#ifdef _DEBUG

bool NPGame::UnitTest()
{
	std::vector<NPClientID> playerHashes;

	IPaddress tempAddr = NPHelper::CreateIPAddressObject( 127, 0, 0, 1, 5000 );

	playerHashes.push_back( NPClientID( (int)time(0)+00, tempAddr, "Test1", true ) ); 
	playerHashes.push_back( NPClientID( (int)time(0)+10, tempAddr, "Test2", true ) );
	playerHashes.push_back( NPClientID( (int)time(0)+20, tempAddr, "Test3", true ) );
	playerHashes.push_back( NPClientID( (int)time(0)+30, tempAddr, "Test4", true ) );

	NPGame * testGame = new NPGame( "Unit Test Game", playerHashes );
	
	testGame->DumpAllInfo();
	testGame->Shuffle();
	testGame->DumpAllInfo();
	testGame->Deal(4);
	testGame->DumpAllInfo();

	printf("Debug: Card shown to all: %s\n", testGame->m_cards.front()->GetReadable().c_str() );
	printf("Player 3's hand is [%s]\n", testGame->GetHand(2).c_str() );

	delete testGame;

	printf("\nNPGame UnitTest Complete.\n\n" );

	return true;
}

#endif //_DEBUG