#pragma once

#include <vector>
#include <deque>
#include <string>

#include "NPClientID.h"

#define NUM_CARDS_START			6
#define NP_PICK_UP_CARDS_AMOUNT 2

class NPCard;

struct NPPlayerHand
{
	NPClientID m_player;
	std::vector<NPCard*> m_cards;
	bool m_playing;
};

class NPGame
{
public:
	NPGame(std::string name, std::vector<NPClientID> players );
	~NPGame(void);

	unsigned int Hash() { return m_hash; }
	void Shuffle();
	void Deal(const unsigned short numPlayers);
	bool ProcessTurn( unsigned int playerHash, short whichCard );
	bool IsLogicalMove( NPCard* toPlay );
	unsigned short WhoseTurn();
	unsigned short WhoseTurn( unsigned int& hash );
	std::string GetGameState( unsigned short whichPlayer );
	bool PickUpCard( unsigned short whichPlayer, unsigned short howMany );
	bool PutDownCard( unsigned short whichPlayer, unsigned short whichCard );
	std::string GetHand( unsigned short whichPlayer );
	unsigned short GetPlayerID( unsigned int hash );
	unsigned short HasAnyoneWon();
	
	NPClientID GetParticipant( unsigned short whichPlayer ) { return m_hands.at(whichPlayer).m_player; }
	NPClientID GetParticipantFromHash( unsigned int hash );

	NPCard* GetTopCard() { return m_cards.front(); }
	void StopPlaying( unsigned short who ) { m_hands[who].m_playing = false; }

#ifdef _DEBUG
	void DumpAllInfo();
	static bool UnitTest();
#endif //_DEBUG

private:
	std::deque<NPCard*> m_cards;       // the card stack

	std::vector<NPPlayerHand> m_hands; // each hand
	unsigned short m_whoseTurn;		   // an index into m_hands to represent the current player (starts 0)

	short m_totalCards;				   // total number of cards
	
	const std::string m_name;		   // the name of the game
	const unsigned int m_hash;		   // the unique hash identifier of the game

};
