#include <stdlib.h>
#include <conio.h>
#include <assert.h>

#include "SDL_net.h"
#include "SDL_thread.h"

#include "NPNetworkDistributor.h"

#include "NPGame.h"
#include "NPClientID.h"
#include "NPClientGroup.h"

#include "../NP-Shared/NPNetworkInterface.h"
#include "../NP-Shared/NPHelper.h"
#include "../NP-Shared/NPCard.h"

// default port to listen on
#define DEFAULT_PORT		5500
// seconds between sending out an updated lobby list
#define LOBBY_LIST_DELAY	1
// updates, not seconds - between purging old messages
#define PURGE_FREQUENCY     100

// the network interface
NPNetworkInterface*		g_pNetworkInterface;

// a group of chatters (in the lobby)
NPClientGroup			g_clientGroupChat;

// store/manager to all games that are currently active
std::vector<NPGame*>	g_games;

//static (local) variable instantiation - server's 'unique' hash (unused)
unsigned int NPNetworkInterface::m_interfaceHash = 537737;

// the time that a list of the lobby chat list was last sent
time_t					g_lastSentLobbyList = 0;

// a list of the lobby-list names last time a message was sent out
std::string				g_prevNameList;

// debug: all multiple clients on this one PC?
bool					g_multClients = false;

bool DumpInfo()
{
	// View connection info

	// Dump NPDistributor Info
	char textLine[255];
	char ipAddress[255];

	printf( "\n ** Dumping Info ** \n\n" );
	printf( " * Distributor Info *\n\n" );

	printf( " Interface Name: %s\n", g_pNetworkInterface->GetInterfaceName() );

	IPaddress localIPAddress = g_pNetworkInterface->GetLocalIPAddress();
	NPHelper::GetReadableIPAddress( localIPAddress, ipAddress, true );
	sprintf_s( textLine, 255, " Local IP: %s", ipAddress );
	printf( "%s\n", textLine );
	memset( textLine, ' ', 255 );

	printf("\n * Registered Clients *\n\n");

	// Dump Client Info
	g_clientGroupChat.DumpAll();

	printf("\n ** End Dump **\n\n" );

	return true;
}

void Init(short port)
{
	// initialize SDL_net
	if( SDLNet_Init() == -1 )
	{
		printf("SDLNet_Init: %s\n",SDLNet_GetError());
		exit(1);
	}

	// Register SDL_Quit to be called at exit; makes sure things are
	// cleaned up when we quit.
	atexit( SDL_Quit );

	// Init seed (for random number generation)
	srand( (int)time(0) );

	// Init Network Thread
	g_pNetworkInterface = new NPNetworkInterface( "Interface Server", g_multClients );
	g_pNetworkInterface->InitializeServer( port );
}

int Update()
{
	// Gameserver stuff - logic!
	// Get next message to be dealt with
	NPNetMessage newMsg = g_pNetworkInterface->GetNextMessage( false );

	// If this message is meaningful
	if ( newMsg.GetMessageType() != MSG_NULL )
	{
		// Process it!
		switch ( newMsg.GetMessageType() )
		{
			case MSG_CHAT_MESSAGE:
			{
				// Rcvd a standard chat message from a client

				if ( !g_clientGroupChat.DoesClientHashExist( newMsg.Hash() ) )
					g_clientGroupChat.CreateClient( newMsg.GetSource(), newMsg.Hash(), "", g_multClients );

				// ping this message back to all connected!
				
				std::vector<NPClientID> temp = g_clientGroupChat.GetAllClients();
				std::vector<NPClientID>::iterator iter;

				for ( iter = temp.begin(); iter != temp.end(); ++iter )
				{
					g_pNetworkInterface->AddNewMessage( NPNetMessage( 
												g_pNetworkInterface->GetLocalIPAddress(),
												(*iter).GetAddress(),
												newMsg.GetData(),
												MSG_CHAT_MESSAGE ), true );
				}
				break;
			}

			case MSG_NAME_REQUEST:
			{
				// The server shouldn't be being asked questions about names!
				// The server sends out the lobby chat list, and only when
				// it decides there has been a change.
				assert(0);
				break;
			}

			case MSG_NAME_UPDATE:
			{
				// A client has told us they would like to update their name
				g_clientGroupChat.UpdateClientName( newMsg.Hash(), newMsg.GetTextData() );
				break;
			}

			case MSG_PING:
			{
				// the client is pinging the server
				
				// if they don't already exist, let's add them!
				if ( !g_clientGroupChat.DoesClientHashExist( newMsg.Hash() ) )
					g_clientGroupChat.CreateClient( newMsg.GetSource(), newMsg.Hash(), "", g_multClients );

				// by now the client MUST exist so, store as hash, then retrieve as client
				// - this ensures creation worked and collects address correctly
				NPClientID thisClient = g_clientGroupChat.GetClientFromHash( newMsg.Hash() );

				if ( thisClient.GetAddress().host != 0 )
				{
					// we've had a good message from this client - let's record this
					g_clientGroupChat.UpdateClientConnectionStatus( newMsg.Hash(), true );

					// send a 'pong' message back
					g_pNetworkInterface->AddNewMessage( NPNetMessage( g_pNetworkInterface->GetLocalIPAddress(),
																	  thisClient.GetAddress(),
																	  "(PONG)",
																	  MSG_PONG ), true );

					// if we don't have a name for this client, let's ask them for it!
					if ( thisClient.GetName() == "" )
					{
						g_pNetworkInterface->AddNewMessage( NPNetMessage( g_pNetworkInterface->GetLocalIPAddress(),
																		  thisClient.GetAddress(),
																		  "(What's your name?)",
																		  MSG_NAME_REQUEST ), true );
					}
				}
				else
				{
					// unknown client pinged us, and we couldn't add them as a client?
					assert(0);
				}
				break;								  
			}

			case MSG_START_GAME:
			{
				// a client ( newMsg.Hash() ) wants to start the game...
				if ( g_clientGroupChat.GetNumClientsConnected() == 4 )
				{
					//start a game!
					// MOVE (the only) 4 players from chatroom context to this new game context
					NPGame* newGame = new NPGame( "Standard Game", g_clientGroupChat.GetAllClients() );

					newGame->Shuffle();
					newGame->Deal(4);

					// update all players with this new game!

					char buffer[256];

					// tell all players the latest info
					// NB. Player ordering L->R visually MUST BE:
					// ply1 plays against 2, 3, 4
					// ply2 plays against 3, 4, 1
					// ply3 plays against 4, 1, 2
					// ply4 plays against 1, 2, 3
					// otherwise this will impede logical turn ordering - this way, from every
					// players perspective, the turn ordering will go 'clockwise'

					std::string ply1Hand = newGame->GetHand(0);
					std::string ply2Hand = newGame->GetHand(1);
					std::string ply3Hand = newGame->GetHand(2);
					std::string ply4Hand = newGame->GetHand(3);
					std::string topCard = newGame->GetTopCard()->GetReadableShort();

					unsigned int temp;
					unsigned short whoseTurn = newGame->WhoseTurn(temp);

					// MSG_GAME_UPDATE takes a CSV as such:
					// "gamehash", "PLAYERS_CARDS_STR", "STACK_CARD", "OPP1_NUMCARDS",
					//                                      "OPP2_NUMCARDS", "OPP3_NUMCARDS", "MYTURN?1:0"
					// i.e. ( "1075913", "1124558", "8", "2", "3", "5", "0", )


					// PLAYER 1's start game message

					sprintf_s( buffer, 256, "%u,%s,%s,%u,%u,%u,%u,%s,%s,%s,",
								newGame->Hash(),  // the GAME hash
								ply1Hand.c_str(), // player's hand in a string ( "1252335" )
								topCard.c_str(),  // the top card
								(short)ply2Hand.size(), // number of player 2's cards
								(short)ply3Hand.size(), // number of player 3's cards
								(short)ply4Hand.size(), // number of player 4's cards
								(short)(whoseTurn == 0 ? 1 : 0), // whether it is player 1's turn or not
								newGame->GetParticipant(1).GetName().c_str(), //ply 1's name
								newGame->GetParticipant(2).GetName().c_str(), //ply 1's name
								newGame->GetParticipant(3).GetName().c_str()  //ply 1's name
								);

					g_pNetworkInterface->AddNewMessage( NPNetMessage(
								g_pNetworkInterface->GetLocalIPAddress(),
								newGame->GetParticipant( 0 ).GetAddress(),
								std::string(buffer),
								MSG_START_GAME ), true );


					// PLAYER 2's start game message

					sprintf_s( buffer, 256, "%u,%s,%s,%u,%u,%u,%u,%s,%s,%s,",
								newGame->Hash(),  // the GAME hash
								ply2Hand.c_str(), // player's hand in a string ( "1252335" )
								topCard.c_str(),  // the top card
								(short)ply3Hand.size(), // number of player 3's cards
								(short)ply4Hand.size(), // number of player 4's cards
								(short)ply1Hand.size(), // number of player 1's cards
								(short)(whoseTurn == 1 ? 1 : 0), // whether it is player 2's turn or not
								newGame->GetParticipant(2).GetName().c_str(), //ply 3's name
								newGame->GetParticipant(3).GetName().c_str(), //ply 4's name
								newGame->GetParticipant(0).GetName().c_str()  //ply 1's name
								);

					g_pNetworkInterface->AddNewMessage( NPNetMessage(
								g_pNetworkInterface->GetLocalIPAddress(),
								newGame->GetParticipant( 1 ).GetAddress(),
								std::string(buffer),
								MSG_START_GAME ), true );


					// PLAYER 3's start game message

					sprintf_s( buffer, 256, "%u,%s,%s,%u,%u,%u,%u,%s,%s,%s,",
								newGame->Hash(),  // the GAME hash
								ply3Hand.c_str(), // player's hand in a string ( "1252335" )
								topCard.c_str(),  // the top card
								(short)ply4Hand.size(), // number of player 4's cards
								(short)ply1Hand.size(), // number of player 1's cards
								(short)ply2Hand.size(), // number of player 2's cards
								(short)(whoseTurn == 2 ? 1 : 0), // whether it is player 3's turn or not
								newGame->GetParticipant(3).GetName().c_str(), //ply 4's name
								newGame->GetParticipant(0).GetName().c_str(), //ply 1's name
								newGame->GetParticipant(1).GetName().c_str()  //ply 2's name
								); 

					g_pNetworkInterface->AddNewMessage( NPNetMessage(
								g_pNetworkInterface->GetLocalIPAddress(),
								newGame->GetParticipant( 2 ).GetAddress(),
								std::string(buffer),
								MSG_START_GAME ), true );


					// PLAYER 4's start game message

					sprintf_s( buffer, 256, "%u,%s,%s,%u,%u,%u,%u,%s,%s,%s,",
								newGame->Hash(),  // the GAME hash
								ply4Hand.c_str(), // player's hand in a string ( "1252335" )
								topCard.c_str(),  // the top card
								(short)ply1Hand.size(), // number of player 2's cards
								(short)ply2Hand.size(), // number of player 3's cards
								(short)ply3Hand.size(), // number of player 4's cards
								(short)(whoseTurn == 3 ? 1 : 0), // whether it is player 4's turn or not
								newGame->GetParticipant(0).GetName().c_str(), //ply 1's name
								newGame->GetParticipant(1).GetName().c_str(), //ply 2's name
								newGame->GetParticipant(2).GetName().c_str()  //ply 3's name
								);

					g_pNetworkInterface->AddNewMessage( NPNetMessage(
								g_pNetworkInterface->GetLocalIPAddress(),
								newGame->GetParticipant( 3 ).GetAddress(),
								std::string(buffer),
								MSG_START_GAME ), true );


					g_games.push_back( newGame );
				
					printf( "\n%s: **************** Starting a Game (%x) ****************\n", "Server", newGame->Hash() );
					
				}
				else
				{
					IPaddress initiator = g_clientGroupChat.GetClientFromHash( newMsg.Hash() ).GetAddress();

					// Let's send a nice message back to this person who asked for a game

					char msg[128];
					sprintf_s( msg, 128, "%s: Incorrect number of players in lobby (%u)", "Server",
																	g_clientGroupChat.GetNumClientsConnected() );

					g_pNetworkInterface->AddNewMessage( NPNetMessage( g_pNetworkInterface->GetLocalIPAddress(),
																	  initiator,
																	  std::string(msg),
																	  MSG_CHAT_MESSAGE ), true );
				}
				break;
			}
			case MSG_PURGE_THIS_IP:
			{
				// This is a messages from the network interface to remove an IP address we have stored
				std::string ipAddr = newMsg.GetTextData();
				IPaddress badIP = NPHelper::GetIPaddress( ipAddr.c_str() );
				printf("%s: Purging a bad IP! IP is %s\n", "Server", ipAddr.c_str() );
				if ( !g_clientGroupChat.RemoveClient( badIP ) )
				{
					printf("%s: Could not remove this IP (Already removed?", "Server" );
				}
				break;
			}
			case MSG_GAME_PROCESS_MOVE:
			{
				// player has selected a card they'd like
				int cardIndex = newMsg.GetNumericData();
				std::string cardName = "";
				
				bool processedOK = false;
				NPGame* thisGame = 0;
				
				// search all the games to see which this player is involved in
				for ( unsigned int i = 0; i < g_games.size(); ++i )
				{
					if ( g_games.at(i)->GetPlayerID( newMsg.Hash() ) != -1  )
					{
						thisGame = g_games.at(i);
						if ( newMsg.GetNumericData() != -1 )
						{
							// grab the card name before too late
							cardName = thisGame->GetHand( thisGame->GetPlayerID( newMsg.Hash() ) ).at( newMsg.GetNumericData() );
						}
						processedOK = thisGame->ProcessTurn( newMsg.Hash(), newMsg.GetNumericData() );
					}
				}
				
				if ( processedOK )
				{
					// legal move made - tell all connected clients
					// update all players with this new move!

					// NB. Player ordering L->R visually MUST BE:
					// ply1 plays against 2, 3, 4
					// ply2 plays against 3, 4, 1
					// ply3 plays against 4, 1, 2
					// ply4 plays against 1, 2, 3
					// otherwise this will impede logical turn ordering - this way, from 
					// every players perspective, the turn ordering should go 'clockwise'

					// MSG_GAME_UPDATE takes a CSV string as such:
					// "gamehash", "PLAYERS_CARDS_STR", "STACK_CARD", "OPP1_NUMCARDS",
					//                                      "OPP2_NUMCARDS", "OPP3_NUMCARDS", "MYTURN?1:0"
					// i.e. ( "1075913", "1124558", "8", "2", "3", "5", "0", )

					char buffer[256];

					if ( newMsg.GetNumericData() == -1 )
					{
						sprintf_s( buffer, 256, "%s had to pick up %u!", 
							thisGame->GetParticipantFromHash( newMsg.Hash() ).GetName().c_str(),
							(short)NP_PICK_UP_CARDS_AMOUNT );
					}
					else
					{
						//ASCII Hack
						sprintf_s( buffer, 256, "%s played a %s.", 
							thisGame->GetParticipantFromHash( newMsg.Hash() ).GetName().c_str(), 
							cardName.c_str() );
					}

					// send a message to all connected to game!
					for (int i = 0; i < 4; ++i )
					{
						g_pNetworkInterface->AddNewMessage( NPNetMessage(
							g_pNetworkInterface->GetLocalIPAddress(),
							thisGame->GetParticipant(i).GetAddress(),
							buffer,
							MSG_CHAT_MESSAGE ), true );
					}

					unsigned int winnerHash = thisGame->HasAnyoneWon();
					// Check win condition!
					if ( winnerHash != 0 )
					{
						//someone (idx [winner]) has won!
						sprintf_s(buffer, 256, "%s has won!!", thisGame->GetParticipant(winnerHash).GetName().c_str() );
						for (int i = 0; i < 4; ++i )
						{
							g_pNetworkInterface->AddNewMessage( NPNetMessage(
								g_pNetworkInterface->GetLocalIPAddress(),
								thisGame->GetParticipant(i).GetAddress(),
								buffer,
								MSG_CHAT_MESSAGE ), true );
						}
						thisGame->StopPlaying(winnerHash);
						// continue playing?
					}

					unsigned short whoseTurn = thisGame->WhoseTurn();

					// helpful for clarity in below code
					std::string ply1Hand = thisGame->GetHand(0);
					std::string ply2Hand = thisGame->GetHand(1);
					std::string ply3Hand = thisGame->GetHand(2);
					std::string ply4Hand = thisGame->GetHand(3);
					std::string topCard = thisGame->GetTopCard()->GetReadableShort();
					
					// PLAYER 1's update message

					sprintf_s( buffer, 256, "%u,%s,%s,%u,%u,%u,%u,",
								thisGame->Hash(), // the GAME hash
								ply1Hand.c_str(), // player's hand in a string ( "1252335" )
								topCard.c_str(), // the top card
								(short)ply2Hand.size(), // number of player 2's cards
								(short)ply3Hand.size(), // number of player 3's cards
								(short)ply4Hand.size(), // number of player 4's cards
								(short)(whoseTurn == 0 ? 1 : 0) ); // whether it is player 1's turn or not

					g_pNetworkInterface->AddNewMessage( NPNetMessage(
								g_pNetworkInterface->GetLocalIPAddress(),
								thisGame->GetParticipant( 0 ).GetAddress(),
								std::string(buffer),
								MSG_GAME_UPDATE ), true );

					// PLAYER 2's update message

					sprintf_s( buffer, 256, "%u,%s,%s,%u,%u,%u,%u,",
								thisGame->Hash(), // the GAME hash
								ply2Hand.c_str(), // player's hand in a string ( "1252335" )
								topCard.c_str(), // the top card
								(short)ply3Hand.size(), // number of player 3's cards
								(short)ply4Hand.size(), // number of player 4's cards
								(short)ply1Hand.size(), // number of player 1's cards
								(short)(whoseTurn == 1 ? 1 : 0 ) ); // whether it is player 2's turn or not

					g_pNetworkInterface->AddNewMessage( NPNetMessage(
								g_pNetworkInterface->GetLocalIPAddress(),
								thisGame->GetParticipant( 1 ).GetAddress(),
								std::string(buffer),
								MSG_GAME_UPDATE ), true );

					// PLAYER 3's update message

					sprintf_s( buffer, 256, "%u,%s,%s,%u,%u,%u,%u,",
								thisGame->Hash(), // the GAME hash
								ply3Hand.c_str(), // player's hand in a string ( "1252335" )
								topCard.c_str(), // the top card
								(short)ply4Hand.size(), // number of player 4's cards
								(short)ply1Hand.size(), // number of player 1's cards
								(short)ply2Hand.size(), // number of player 2's cards
								(short)(whoseTurn == 2 ? 1 : 0) ); // whether it is player 3's turn or not

					g_pNetworkInterface->AddNewMessage( NPNetMessage(
								g_pNetworkInterface->GetLocalIPAddress(),
								thisGame->GetParticipant( 2 ).GetAddress(),
								std::string(buffer),
								MSG_GAME_UPDATE ), true );


					// PLAYER 4's update message

					sprintf_s( buffer, 256, "%u,%s,%s,%u,%u,%u,%u,",
								thisGame->Hash(), // the GAME hash
								ply4Hand.c_str(), // player's hand in a string ( "1252335" )
								topCard.c_str(), // the top card
								(short)ply1Hand.size(), // number of player 2's cards
								(short)ply2Hand.size(), // number of player 3's cards
								(short)ply3Hand.size(), // number of player 4's cards
								(short)(whoseTurn == 3 ? 1 : 0) ); // whether it is player 4's turn or not

					g_pNetworkInterface->AddNewMessage( NPNetMessage(
								g_pNetworkInterface->GetLocalIPAddress(),
								thisGame->GetParticipant( 3 ).GetAddress(),
								std::string(buffer),
								MSG_GAME_UPDATE ), true );

					printf( "%s: ******** Processed a turn!! ******** \n", "Server" );
				}
				else
				{
					//illegal move proffered! ignore!
					//assert(0); // should be ok...
				}
				
				break;
			}
			default:
			{
				assert(0); // this message is not being dealt with!!
				break;
			}
		}
	}
	else
	{
		// nothing to do... send out a list of all the chatters to update chat lobby lists!
		time_t now = time(0);
		
		if ( now - g_lastSentLobbyList >= LOBBY_LIST_DELAY )
		{
			g_lastSentLobbyList = now;
			// send out an update to all clients of the chat members
			// (MSG_CHAT_PARTICIPANTS_LIST)
			
			std::string lobbyList;
			std::vector<std::string> listOfChatters = g_clientGroupChat.GetAllClientNames();

			for ( unsigned int i = 0; i < listOfChatters.size(); ++i )
			{
				lobbyList += listOfChatters.at(i) + ",";
			}

			if ( g_prevNameList == lobbyList )
			{
				// names haven't changed since last msg... don't bother
			}
			else
			{
				std::vector<NPClientID> allClients = g_clientGroupChat.GetAllClients();

				// send this message back to all connected!
				for ( int i = 0; i < g_clientGroupChat.GetNumClientsConnected(); ++i )
				{
					g_pNetworkInterface->AddNewMessage( NPNetMessage(
														 g_pNetworkInterface->GetLocalIPAddress(),
														 allClients.at(i).GetAddress(),
		    											 lobbyList,
														 MSG_CHAT_PARTICIPANTS_LIST ), true );
				}

				g_prevNameList = lobbyList;
			}
		}
	}

	// if it has been PURGE_FREQUENCY updates since last purge, attempt to purge again.
	static int i = 0; ++i;
	if ( i % PURGE_FREQUENCY == 0 )
		g_pNetworkInterface->RequestPurgeOldMessages();

	return 0;
}


// Entry point
int main( int argc, char *argv[] )
{
	// Unit Tests!
#ifdef _DEBUG
	assert( NPHelper::UnitTest() );
	assert( NPGame::UnitTest() );	
#endif

	// allow command line arguments for port numbers
	unsigned short port = DEFAULT_PORT;
	if ( argc > 1 ) 
		g_multClients = true;

	Init(port);

	// Main loop
	while (1)
	{
		static int gameLoop = 0; gameLoop++;
		if ( gameLoop % 100000 == 0 )
			printf("%s: Gameloop[%i]\n", "Server", gameLoop);

		// Update
		if ( Update() == -1 ) return (1);

		if( _kbhit() )
		{
			char keyIn = _getch();

			if ( keyIn == 'q' || keyIn == 0x1b ) // q or ESC
				return 0;
			else if ( keyIn == 'i' )
				DumpInfo();
		}

	}
	return 0;
}
