#include "NPNetworkDistributor.h"

#include "../NP-Shared/NPNetworkInterface.h"
#include "../NP-Shared/NPMessageTypes.h"
#include "../NP-Shared/NPHelper.h"

#include "SDL_thread.h"
#include "SDL_timer.h"
#include "SDL_mutex.h"

#include <assert.h>

// NPNetworkDistributor
// This threaded Server-specific class is designed to receive new Client connections 
// and assign dedicated NPNetworkInterface objects to them

SDL_mutex *distLock;

NPNetworkDistributor::NPNetworkDistributor(void)
{
	m_interfaceName = "NetworkDistributor";
}

NPNetworkDistributor::~NPNetworkDistributor(void)
{
	
}

bool NPNetworkDistributor::Update()
{
	// These Threaded Update calls must repeat on their own :'( //tbd
	m_numActiveConnections = 0;
	TCPsocket newConnection;
	IPaddress newConnectionIP;
	char ourIPAddress[30];

	// accept connections, and create a NetworkInterface object for each
	while ( true )
	{
		// manage any games that need managing
		for ( int i = 0; i < m_numActiveConnections; ++i )
		{
			NPNetMessage temp = m_ppNI[i]->GetNextMessage(false); // only get messages we have recv'd!
			if ( temp.GetSize() >= 0 ) //tbd can we have null size msgs?
			{
				// manage game
				//tbd
			}
		}

		// poll for new connections
		NPHelper::GetReadableIPAddress(m_localIP, ourIPAddress, true );
		printf( "%s: Scanning for new connections on %s...\n", m_interfaceName, ourIPAddress );

		// try to accept a connection
		newConnection = SDLNet_TCP_Accept( m_localSocket );	

		if ( newConnection )
		{
			newConnectionIP = *( SDLNet_TCP_GetPeerAddress( newConnection ) );

			//debug
			// check the client hasn't already been added
			for ( int i = 0; i < m_numActiveConnections; ++i )
			{
				if ( newConnectionIP.host == m_ppNI[i]->GetLocalIP() &&
					 newConnectionIP.port == m_ppNI[i]->GetLocalPort() )
				{
					assert(0);  // this port is already being connected to by a client
								// either this client now connecting or another existing client!
				}
			}

			char name[30];
			sprintf_s( name, 30, "Server-Client #%d", m_numActiveConnections );

			char newClientIPAddressReadable[30];
			NPHelper::GetReadableIPAddress( newConnectionIP, newClientIPAddressReadable, false );
			unsigned short newClientIPAddressPort;
			NPHelper::GetReadableIPAddressPort( newConnectionIP, newClientIPAddressPort );

			m_ppNI[m_numActiveConnections] = new NPNetworkInterface( name );
			m_ppNI[m_numActiveConnections]->InitializeDedicatedServer( newClientIPAddressReadable,
																	   newClientIPAddressPort,
																	   BASE_PORT_NUMBER + m_numActiveConnections );

			//log
			printf( "%s: Allocating new NetworkInterface %s for client #%d\n", m_interfaceName, name, m_numActiveConnections );

			m_numActiveConnections++;
		}

		SDL_Delay(SOCKET_RW_DELAY);
	}
	return false;
}

void NPNetworkDistributor::Initialize( unsigned short port, NPNetworkInterface** ppNI, short maxConnections )
{
	m_ppNI = ppNI;

	// Resolve the argument into an IPaddress type
	if( SDLNet_ResolveHost( &m_localIP, NULL, port )== -1 )
	{
		printf( "SDLNet_ResolveHost: %s\n", SDLNet_GetError() );
		exit(1);
	}
	
	// by this point m_localIP.host will resolve to INA#DDR_ANY
	// this is fine - as in, it doesn't care what it's own IP is.
	//tbd check

	// open the server socket
	m_localSocket = SDLNet_TCP_Open( &m_localIP );
	if( !m_localSocket )
	{
		printf( "SDLNet_TCP_Open: %s\n", SDLNet_GetError() );
		exit(2);
	}

	// 0.0.0.0 *should* default resolving to 127.0.0.1
	// occasionally it... doesn't. Let's ensure it does here.
	//if ( m_localIP.host == 0 )
	//{
	//	unsigned int temp = 1;
	//	temp = temp<<24;
	//	temp += 127;
	//	m_localIP.host = temp;
	//}

	char ipAddrReadable[30];
	NPHelper::GetReadableIPAddress( m_localIP, ipAddrReadable, true );

	printf( " * %s started on %s *\n",
		m_interfaceName,
		ipAddrReadable );

	// Finally create the thread
	SDL_Thread *thread;
    thread = SDL_CreateThread( &NPNetworkDistributor::ThreadUpdate, this );
    if ( thread == NULL )
	{
        printf( "Unable to create thread: %s\n", SDL_GetError() );
		exit(3);
    }
}

int NPNetworkDistributor::ThreadUpdate( void* selfRefPtr )
{
	distLock = ( SDL_mutex* )selfRefPtr;

	return ( static_cast< NPNetworkDistributor* >(selfRefPtr)->Update() );
}