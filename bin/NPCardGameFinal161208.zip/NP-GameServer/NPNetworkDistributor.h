#pragma once

#include "SDL_net.h"
#include "..\NP-Shared\NPNetMessage.h"
#include "..\NP-Shared\NPNetworkInterface.h"

#define BASE_PORT_NUMBER 7000

class NPNetworkDistributor
{
public:
	NPNetworkDistributor(void);
	~NPNetworkDistributor(void);

public:
	void Initialize( unsigned short port, NPNetworkInterface** ppNI, short maxConnections );
	static int ThreadUpdate( void* selfRefPtr );
	bool Update(void);

	IPaddress GetLocalIPAddress() { return m_localIP; }
	char* GetInterfaceName() { return m_interfaceName; }

private:
	IPaddress m_localIP; //also contains port
	TCPsocket m_localSocket;
	char* m_interfaceName;
	NPNetworkInterface** m_ppNI; // pointer to the array of network interface objects,
								 // managed by NPGameServer, but accessed here.
	int m_numActiveConnections;
};
