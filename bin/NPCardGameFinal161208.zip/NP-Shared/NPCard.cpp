#include "NPCard.h"
#include <assert.h>

///////////////////////////////////////////////////////////////////
// NPCard                                                        //
// This simple class holds the value of a single card as used in //
// the NPGame class, and user-friendly std::string get functions.//
///////////////////////////////////////////////////////////////////

NPCard::NPCard( NPCARDTYPE type, short value ) : m_type( type ), m_value( value )
{
	assert( m_value >= 0 && m_value <= 10 );
}

NPCard::~NPCard(void)
{
}

std::string NPCard::GetReadable()
{
	std::string retVal;
	switch ( m_type )
	{
	case NPCARDTYPE_NORMAL:
		retVal += "Normal Card: ";
		break;
	case NPCARDTYPE_WILD:
		retVal += "Wild Card: ";
		break;
	default:
		assert(0);
		break;
	}

	char buffer[8];
	sprintf_s( buffer, 8, "%u", m_value );
	retVal += buffer;

	return retVal;
}

std::string NPCard::GetReadableShort()
{
	std::string retVal;
	switch ( m_type )
	{
	case NPCARDTYPE_NORMAL:
		retVal += "";
		char buffer[8];
		sprintf_s( buffer, 8, "%u", m_value );
		retVal += buffer;
		break;
	case NPCARDTYPE_WILD:
		retVal += "*";
		break;
	case NPCARDTYPE_NULL:
		retVal += "_";
		break;
	default:
		assert(0);
		break;
	}


	return retVal;
}