#pragma once

#include <string>

enum NPCARDTYPE { NPCARDTYPE_NULL = 0, NPCARDTYPE_NORMAL, NPCARDTYPE_WILD };

class NPCard
{
public:
	NPCard( NPCARDTYPE type, short value );
public:
	~NPCard(void);

public:
	short GetValue() { return m_value; }
	std::string GetReadable();
	std::string GetReadableShort();

private:
	short m_value;
	NPCARDTYPE m_type;
};
