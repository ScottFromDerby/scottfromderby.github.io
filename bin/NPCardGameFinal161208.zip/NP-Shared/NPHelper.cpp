#include "NPHelper.h"
#include "SDL_net.h"
#include <stdio.h>
#include <assert.h>
#include <time.h>

///////////////////////////////////////////////////////////////////
// NPHelper                                                      //
// This static class (or collection of functions) provide generic//
// helper-functions to commonly used functionality, such as      //
// parsing IPaddress struct into readable segments, creating new //
// IPaddress structs, parsing a CSV list into a vector of strings//
// and random number generation.                                 //
///////////////////////////////////////////////////////////////////


IPaddress NPHelper::GetIPaddress( const char* input )
{
	IPaddress retVal;

	//I'm not 100% sure why, but any less than 7 causes stack corruption here
	unsigned char host[8] = {0,0,0,0}; 
	unsigned int port = 0;

	//"%u%*c%u%*c%u%*c%u%*c%u" means:
	// %u   unsigned int
	// %*c  some character or symbol, but don't pass this to the args
	// so:  number symbol number symbol number symbol number symbol number
	// i.e. 127.0.0.1:40

	if ( sscanf_s( input, "%u%*c%u%*c%u%*c%u%*c%u", &host[0], &host[1], &host[2], &host[3], &port ) == -1 )
	{
		assert(0);// something bad happened!
	}

	retVal = CreateIPAddressObject( host[0], host[1], host[2], host[3], port );
	return retVal;
}

IPaddress NPHelper::GetIPaddress( const char* input, const short inPort )
{
	IPaddress retVal;

	unsigned char host[8] = {0,0,0,0};
	unsigned short port = inPort;

	if ( sscanf_s( input, "%u%*c%u%*c%u%*c%u", &host[0], &host[1], &host[2], &host[3] ) == -1 )
	{
		assert(0);// something bad happened!
	}

	retVal = CreateIPAddressObject( host[0], host[1], host[2], host[3], port );
	return retVal;
}

bool NPHelper::GetReadableIPAddress( const IPaddress ipIn, char* out, bool withPort )
{
	unsigned short portUnwrapped = 0;
	unsigned int ipUnwrapped = 0;
	SDLNet_Write32( ipIn.host, &ipUnwrapped );
	SDLNet_Write16( ipIn.port, &portUnwrapped );

	if ( ipIn.host == 0 )
	{
		// the IP is 0.0.0.0
		// which is the same as INADDR_ANY
		if ( withPort )
		{
			sprintf_s( out, 30, "port %u", portUnwrapped );
		}
		else
		{
			sprintf_s( out, 30, "_ANY_" );
		}
	}
	else
	{
		if ( withPort )
		{
			sprintf_s( out, 30, "%u.%u.%u.%u:%u", ipUnwrapped>>24,
												  (ipUnwrapped>>16)&0xff,
												  (ipUnwrapped>>8)&0xff,
												  ipUnwrapped&0xff,
												  portUnwrapped );
		}
		else
		{
			sprintf_s( out, 30, "%u.%u.%u.%u", ipUnwrapped>>24,
											   (ipUnwrapped>>16)&0xff,
											   (ipUnwrapped>>8)&0xff,
											   ipUnwrapped&0xff );
		}
	}
	return true;
}
	
IPaddress NPHelper::CreateIPAddressObject( unsigned short a, unsigned short b,
								unsigned short c, unsigned short d, unsigned short port )
{
	// NB. this should correctly give us a little-endian (Network Byte Ordered) result

	// first enter it as standard big-endian data
	IPaddress retVal;
	retVal.host = d;
	retVal.host += c * 256;
	retVal.host += b * 256 * 256;
	retVal.host += a * 256 * 256 * 256;
	retVal.port = port;

	// then flip as necessary using SDLNet macros
	retVal.host = SDLNet_Write32( retVal.host, &retVal.host );
	retVal.port = SDLNet_Write16( retVal.port, &retVal.port );

	return retVal; 
}

bool NPHelper::GetReadableIPAddressPort( const IPaddress ipIn, unsigned short &remoteIPPort )
{
	remoteIPPort = SDLNet_Read16(&ipIn.port);
	return true;
}

#ifdef _DEBUG
bool NPHelper::UnitTest()
{
	printf("\nUnitTest - NPHelper\n\n");

	//1
	{
		char ipAddress[30] = "127.0.0.1:20";

		IPaddress ipObj = GetIPaddress( ipAddress, 20 );

		IPaddress temp = CreateIPAddressObject( 127, 0, 0, 1, 20 );

		assert( temp.host == ipObj.host && temp.port == ipObj.port );

		char result[30];
		GetReadableIPAddress( ipObj, result, true );

		printf("1) %s == %s : %s\n", ipAddress, result, strcmp(ipAddress, result) == 0 ? "Passed!" : "Fail!" );

		if ( strcmp(ipAddress, result) != 0 ) 
			return false;
	}
	//2
	{
		char ipAddress[30] = "127.5.66.71";

		IPaddress ipObj = GetIPaddress( ipAddress, 20 );

		IPaddress temp = CreateIPAddressObject( 127, 5, 66, 71, 20 );

		assert( temp.host == ipObj.host && temp.port == ipObj.port );

		char result[30];
		GetReadableIPAddress( ipObj, result, false );

		printf("2) %s == %s : %s\n", ipAddress, result, strcmp(ipAddress, result) == 0 ? "Passed!" : "Fail!" );

		if ( strcmp(ipAddress, result) != 0 ) 
			return false;
	}
	
	printf("\nEnd of NPHelper Unit Tests.\n\n");

	return true;
}
#endif //_DEBUG

int NPHelper::GetRand( const int lower, const int upper )
{
	return ( rand() % ( (upper - lower) + lower) );
}

float NPHelper::GetRand( const float lower, const float upper )
{
	return ( ( rand() / RAND_MAX * 1.0f ) * ( (upper - lower) + lower) );
}

std::vector<std::string> NPHelper::ParseCSV( std::string csvString )
{
	// Parse a comma-seperated values list into strings in a vector
	std::vector<std::string> retVal;

	unsigned int end = 0;
	unsigned short i = 0;

	while ( csvString.size() > 0 )
	{
		if ( csvString.at(i) == ',' )
		{
			// comma hit - store everything up til this point
			retVal.push_back( csvString.substr( 0, i ) );
			csvString.erase( 0, i+1 ); // including the comma
			i = 0;
		}
		else
		{
			++i;
		}
	}

	return retVal;
}