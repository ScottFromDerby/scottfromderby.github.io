#pragma once
#include "SDL_net.h"
#include <vector>
#include <string>

class NPHelper
{
private:
	NPHelper(void) {} // no constructor - we don't want to make classes out of this!

public:
	static IPaddress GetIPaddress( const char* input );
	static IPaddress GetIPaddress( const char* input, const short inPort );

	static bool GetReadableIPAddress( const IPaddress ipIn, char* out, bool withPort );
	static bool GetReadableIPAddressPort( const IPaddress ipIn, unsigned short& port );

	static IPaddress CreateIPAddressObject( unsigned short a, unsigned short b,
								unsigned short c, unsigned short d, unsigned short port );

	static int GetRand( const int lower, const int upper );
	static float GetRand( const float lower, const float upper );

	static std::vector<std::string> ParseCSV( std::string csvString );

#ifdef _DEBUG
	static bool UnitTest();
#endif
};