#include "NPImageBank.h"
#include "SDL_image.h"
#include <assert.h>

///////////////////////////////////////////////////////////////////
// NPImageBank                                                   //
// This class acts as a simple extension to SDLRenderer, in that //
// it instantiates a number of images on creation and manages    //
// them during the running of the program.                       //
///////////////////////////////////////////////////////////////////

NPImageBank::NPImageBank(void)
{
	m_connectionOK = IMG_Load( "..\\NP-Shared\\Resources\\connection_ok.tga" );
	if ( !m_connectionOK ) assert(0);

	m_connectionFail = IMG_Load( "..\\NP-Shared\\Resources\\no_connection.tga" );
	if ( !m_connectionFail ) assert(0);

	m_cardFront = IMG_Load( "..\\NP-Shared\\Resources\\card_empty.tga" );
	if ( !m_cardFront ) assert(0);
	
	m_cardBack = IMG_Load( "..\\NP-Shared\\Resources\\card_back.tga" );
	if ( !m_cardBack ) assert(0);

	m_cardFrontSmall = IMG_Load( "..\\NP-Shared\\Resources\\card_empty_small.tga" );
	if ( !m_cardFrontSmall ) assert(0);

	m_cardBackSmall = IMG_Load( "..\\NP-Shared\\Resources\\card_back_small.tga" );
	if ( !m_cardBackSmall ) assert(0);
}

NPImageBank::~NPImageBank(void)
{
}

SDL_Surface* NPImageBank::GetConnectionStatusImage( bool connIsOK )
{
	if ( connIsOK )
		return m_connectionOK;
	else
		return m_connectionFail;
}