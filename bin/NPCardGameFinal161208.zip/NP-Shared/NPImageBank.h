#pragma once

#include <vector>
#include "SDL.h"

class NPImageBank
{
public:
	NPImageBank(void);
public:
	~NPImageBank(void);
public:
	SDL_Surface* GetConnectionStatusImage( bool connIsOK );
	SDL_Surface* GetCardBackImage() { return m_cardBack; }
	SDL_Surface* GetCardFrontImage() { return m_cardFront; }
	SDL_Surface* GetCardBackSmallImage() { return m_cardBackSmall; }
	SDL_Surface* GetCardFrontSmallImage() { return m_cardFrontSmall; }

private:
	SDL_Surface* m_connectionOK;
	SDL_Surface* m_connectionFail;

	SDL_Surface* m_cardFront;
	SDL_Surface* m_cardBack;
	SDL_Surface* m_cardFrontSmall;
	SDL_Surface* m_cardBackSmall;
};