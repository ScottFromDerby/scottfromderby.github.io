// No dependencies

#define MSG_NULL					0x00
#define MSG_UNUSED1					0x01
#define MSG_UNUSED2				    0x02

// Message explaining that the attached IP should no longer be included in any processing list
#define MSG_PURGE_THIS_IP			0x03

// Standard chat message, sent and recv'd by client and server
#define MSG_CHAT_MESSAGE			0x04

// Unused
#define MSG_REDIRECT_CLIENT_PORT	0x05

// Unused
#define	MSG_UNKNOWN					0x06

// Sent periodically by the server to all chatroom participants
#define MSG_CHAT_PARTICIPANTS_LIST	0x07

// Sent by the server on new client connection
#define MSG_NAME_REQUEST			0x08

// Sent by the client on response to MSG_NAME_REQUEST, or on using \name in chat
#define MSG_NAME_UPDATE				0x09

// Ping and pong...  ping = 'are you there?', pong = 'yup'
#define	MSG_PING					0x0a
#define MSG_PONG					0x0b

// Sent by client when a game is requested - server responds with this message if all is ok to go
// Sent by server when a game is acknowledged and is allowed to start
// When sent by server, contains a CSV with the following
// "gamehash", "PLAYERS_CARDS_STR", "STACK_CARD", "OPP1_NUMCARDS", "OPP2_NUMCARDS", "OPP3_NUMCARDS", "MYTURN?", "OPP1_NAME", "OPP2_NAME", "OPP3_NAME"
// Msg from server - contains a trigger to start the game
#define MSG_START_GAME				0x0c

// Generic update of current player's game info, sent by server
// contains comma seperated values:
// "gamehash", "PLAYERS_CARDS_STR", "STACK_CARD", "OPP1_NUMCARDS", "OPP2_NUMCARDS", "OPP3_NUMCARDS", "MYTURN?"
// i.e. ( "1075913", "1124558", "8", "2", "3", "5", "0", )
#define MSG_GAME_UPDATE				0x0d

// Sent by client, contains a short containing which move to make
// -1 is pick up a card
#define MSG_GAME_PROCESS_MOVE		0x0e

typedef unsigned char BYTE;