#include "NPNetMessage.h"
#include "NPHelper.h"
#include "NPNetworkInterface.h"
#include <sstream>
#include <assert.h>

///////////////////////////////////////////////////////////////////
// NPNetMessage                                                  //
// This class is one of the most important class in this project.//
// It handles encrypting and decrypting messages received to and //
// from all interfaces (client and server), packing & encoding   //
// (and decoding) new messages, and sanity/security checks       //
// at both the server and client. It also handles parsing some   //
// data from messages depending on the content type.             //
///////////////////////////////////////////////////////////////////


NPNetMessage::~NPNetMessage(void)
{
}

NPNetMessage::NPNetMessage( void* dataEncoded, const unsigned int totalSizeOfMsg )
{
	assert ( totalSizeOfMsg != -1 && totalSizeOfMsg != 0 );

	//Decoding ctor
	// NOTE! We have manually here enforced Big Endian when encoding
	// therefore we should decode in Big Endian (e.g. numbers encoded largest part first)

	// here we cast *data to access it
	BYTE* data = new BYTE[totalSizeOfMsg];
	data = (BYTE*)dataEncoded;

	// MSG_TYPE 1
	// MSG_HASH 4
	// MSG_SRC  16
	// MSG_DEST 16
	// MSG_SIZE 2
	// DATA
	
	unsigned short offset = 0;

	m_messageType = data[offset];
	offset += NP_SIZE_OF_MSG_TYPE;

	m_hash = 0;
	m_hash += data[offset+0]*256*256*256;
	m_hash += data[offset+1]*256*256;
	m_hash += data[offset+2]*256;
	m_hash += data[offset+3];
	offset += NP_SIZE_OF_MSG_HASH;

	char* ipSrc = new char[16];
	char* ipDest = new char[16];
	for (int i = 0; i < 16; ++i )
	{
		ipSrc[i]  = data[offset + i];
		ipDest[i] = data[offset + i + NP_SIZE_OF_MSG_SRC];
	}

	m_source =		NPHelper::GetIPaddress( ipSrc, 0 );
	m_destination = NPHelper::GetIPaddress( ipDest, 0 );

	offset += NP_SIZE_OF_MSG_SRC + NP_SIZE_OF_MSG_DEST;
	
	unsigned short size = 0;
	size += data[offset+0]*256;
	size += data[offset+1];

	offset += NP_SIZE_OF_MSG_SIZE;

	for ( int i = 0; i < size; ++i )
	{
		m_data += data[offset+i];
	}
	
	//complete!

	//delete[] data;
	m_sendAttempts = 0;
}
NPNetMessage::NPNetMessage( BYTE msgType )
{
	assert( msgType == MSG_NULL );
	m_messageType = msgType;
	m_data.erase();
	m_source.host = 0;
	m_source.port = 0;
	m_destination.host = 0;
	m_destination.port = 0;
	m_hash = NPNetworkInterface::Hash();
	m_sendAttempts = 0;
}
NPNetMessage::NPNetMessage( const IPaddress src, const IPaddress dest, const std::string data, BYTE msgType )
{	
	m_source = src;
	m_destination = dest;
	m_messageType = msgType;
	m_data = data;
	m_hash = NPNetworkInterface::Hash();
	m_sendAttempts = 0;
}
NPNetMessage::NPNetMessage( const IPaddress src, const IPaddress dest, const int data, BYTE msgType )
{
	m_source = src;
	m_destination = dest;
	m_messageType = msgType;
	char temp[20]; sprintf_s( temp, 20, "%d", data);
	m_data = std::string(temp);
	m_hash = NPNetworkInterface::Hash();
	m_sendAttempts = 0;
}
void NPNetMessage::Pack( const std::string data/*, const unsigned int size*/ )
{
	// add new data to m_data
	//memcpy( m_data, &data, size );
	m_data += data;
}

void NPNetMessage::Pack( const int data )
{
	// add new data to m_data
	char temp[20] = "";
	sprintf_s( temp, 20, "%d", data );
	m_data += temp;

	//recalculate variable size
	//m_dataLength = m_data.size();
}

size_t NPNetMessage::GetNumericData()
{
	// return a numeric value, if this packet is supposed to represent numeric data
	size_t retVal = -1;

	switch ( m_messageType )
	{
		case MSG_REDIRECT_CLIENT_PORT:
		{
			retVal = atoi(m_data.c_str());
			break;
		}
		case MSG_GAME_PROCESS_MOVE:
		{
			// a move from the player - this number is the index into their hand of cards
			retVal = atoi( m_data.c_str() );
			break;
		}
		default:
		{
			assert(0); // what were you trying to do?
			break;
		}
	}

	return retVal;
}

std::string NPNetMessage::GetTextData()
{
	// This returns a logical 'readable' form of the data the message refers to
	std::string retVal;

	switch ( m_messageType )
	{
	case MSG_NAME_REQUEST:
		{
			//server has sent the client a 'get name' request.
			retVal = "";
			break;
		}
	case MSG_NAME_UPDATE:
		{
			//the client is sending a 'my name is' message
			retVal = m_data;
			break;
		}
	case MSG_CHAT_PARTICIPANTS_LIST:
		{
			// the server has sent out a list of the chat participants, comma seperated
			// caller must parse :( sorry
			retVal = m_data;
		}
	case MSG_PURGE_THIS_IP:
		{
			// the server is sending itself a 'this IP is bad' message
			retVal = m_data;
		}
	}

	return retVal;
}

BYTE* NPNetMessage::GetEncoded()
{
	// NB. caller must manage return value!

	// msg data encoded/decoded should be:
	// MSG_TYPE 1  // sizeof(BYTE)
	// MSG_HASH 4  // unsigned int
	// MSG_SRC  16 // "000.000.000.000"
	// MSG_DEST 16 // "000.000.000.000"
	// MSG_SIZE 2  // sizeof(unsigned short)
	// MSG_DATA *  // size = MSG_SIZE

	unsigned short offset = 0;

	// Create a new byte array to pass back
	BYTE* retVal = new BYTE[GetTotalSize()+NP_SIZE_OF_OVERHEAD];

	// Set the first value as the message type
	unsigned short dataLength = m_data.length();
	BYTE len[2];
	len[0] = dataLength << 8;
	len[1] = dataLength % 256;

	char* ipAddrSrc  = new char[16];
	char* ipAddrDest = new char[16];

	NPHelper::GetReadableIPAddress( m_source, ipAddrSrc, false ); // without port!
	NPHelper::GetReadableIPAddress( m_destination, ipAddrDest, false ); // without port!

	// Msg type
	retVal[0] = m_messageType;

	// Msg hash
	offset = NP_SIZE_OF_MSG_TYPE;
	retVal[offset + 0] = ( m_hash >> 24 & 0xff );
	retVal[offset + 1] = ( m_hash >> 16 & 0xff );
	retVal[offset + 2] = ( m_hash >> 8 & 0xff );
	retVal[offset + 3] = ( m_hash & 0xff );

	// Msg src/dest
	offset += NP_SIZE_OF_MSG_HASH;
	for ( int i = 0; i < 16; ++i )
	{
		// fill in both ip src and dest at the same time :) 
		retVal[offset + i] = ipAddrSrc[i];
		retVal[offset + NP_SIZE_OF_MSG_SRC + i] = ipAddrDest[i];
	}

	// Msg size
	offset += NP_SIZE_OF_MSG_DEST + NP_SIZE_OF_MSG_SRC;
	retVal[offset+0] = len[0];
	retVal[offset+1] = len[1];

	// Msg data
	offset += NP_SIZE_OF_MSG_SIZE;
	// copy across character by character the remaining data (payload)
	const char * temp = m_data.c_str();
	for ( unsigned int i = 0; i < m_data.length(); ++i )
		retVal[offset+i] = temp[i];
	
	//delete ipAddrSrc;
	//delete ipAddrDest;

	return retVal;
}

unsigned int NPNetMessage::Hash()
{
	unsigned int retVal;

	//SDL_LockMutex(lock);
	//{
		retVal = m_hash;
	//}
	//SDL_UnlockMutex(lock);

	return retVal;
}

std::string NPNetMessage::GetData()
{
	std::string retVal;

	//SDL_LockMutex(lock);
	//{
		retVal = m_data;
	//}
	//SDL_UnlockMutex(lock);

	return retVal;
}

size_t NPNetMessage::GetDataSize()
{
	size_t retVal;

	//SDL_LockMutex(lock);
	//{
		retVal = m_data.size();
	//}
	//SDL_UnlockMutex(lock);

	return retVal;
}

size_t NPNetMessage::GetTotalSize()
{
	size_t retVal;

	//SDL_LockMutex(lock);
	//{
		retVal = m_data.size() + NP_SIZE_OF_OVERHEAD;
	//}
	//SDL_UnlockMutex(lock);

	return retVal;
}

unsigned short NPNetMessage::IncrSendAttempts()
{
	unsigned short retVal;

	//SDL_LockMutex(lock);
	//{
		retVal = ++m_sendAttempts;
	//}
	//SDL_UnlockMutex(lock);

	return retVal;
}

unsigned short NPNetMessage::GetSendAttempts()
{
	unsigned short retVal;

	//SDL_LockMutex(lock);
	//{
		retVal = m_sendAttempts;
	//}
	//SDL_UnlockMutex(lock);

	return retVal;
}

IPaddress NPNetMessage::GetSource()
{
	IPaddress retVal;

	//SDL_LockMutex(lock);
	//{ 
		retVal = m_source;
	//}
	//SDL_UnlockMutex(lock);
	
	return retVal;
}

IPaddress NPNetMessage::GetDest()
{
	IPaddress retVal;

	//SDL_LockMutex(lock);
	//{ 
		retVal = m_destination;
	//}
	//SDL_UnlockMutex(lock);
	
	return retVal;
}

BYTE NPNetMessage::GetMessageType()
{
	BYTE retVal;

	//SDL_LockMutex(lock);
	//{ 
		retVal = m_messageType;
	//}
	//SDL_UnlockMutex(lock);
	
	return retVal;
}

void NPNetMessage::SetSource( IPaddress source )
{
	//SDL_LockMutex(lock);
	//{ 
		m_source = source;
	//}
	//SDL_UnlockMutex(lock);
}