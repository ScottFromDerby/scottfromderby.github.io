#pragma once
#include "NPMessageTypes.h"
#include <string>

#include "SDL_NET.h"

// breakdown the overhead
#define NP_SIZE_OF_MSG_TYPE 1
#define NP_SIZE_OF_MSG_HASH 4
// below in the form "000.000.000.000"
#define NP_SIZE_OF_MSG_SRC  16 
#define NP_SIZE_OF_MSG_DEST 16
#define NP_SIZE_OF_MSG_SIZE 2

#define NP_SIZE_OF_OVERHEAD ( NP_SIZE_OF_MSG_TYPE + NP_SIZE_OF_MSG_SIZE + NP_SIZE_OF_MSG_HASH + \
						      NP_SIZE_OF_MSG_SRC + NP_SIZE_OF_MSG_DEST )

class NPNetMessage
{
public: // for blank or null data
	NPNetMessage( BYTE msgType );

public: // for decoding data
	NPNetMessage( void* dataEncoded, const unsigned int sizeOfMsg );

public: // for encoding data
	NPNetMessage( const IPaddress src, const IPaddress dest, const std::string data, BYTE msgType );
	NPNetMessage( const IPaddress src, const IPaddress dest, const int data, BYTE msgType );
	
public:
	~NPNetMessage();

	void Pack( const std::string data/*, const unsigned int size*/ );
	void Pack( const int data );
	size_t GetNumericData();
	std::string GetTextData();
	BYTE* GetEncoded();

public: //accessors
	BYTE GetMessageType();

	IPaddress GetSource();
	IPaddress GetDest();

	unsigned int Hash();
	std::string GetData();

	size_t GetDataSize();
	size_t GetTotalSize();
	
	unsigned short IncrSendAttempts();
	unsigned short GetSendAttempts();

public:
	void SetSource( IPaddress source );

private:
	BYTE		 m_messageType;	
	unsigned int m_hash;		// hash of source of the message
	IPaddress	 m_source;		
	IPaddress	 m_destination;	
	//unsigned int m_size;		// tends to get stale unnecessarily
	std::string  m_data;
	
	unsigned short m_sendAttempts; // only for sendable messages
};
