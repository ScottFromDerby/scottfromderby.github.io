//#include "NPNetPacket.h"
//#include "NPNetMessage.h"
//
//NPNetPacket::NPNetPacket(void)
//{
//}
//
//NPNetPacket::~NPNetPacket(void)
//{
//}
//
//NPNetPacket::NPNetPacket(IPaddress src, IPaddress dest, short destPort, NPNetMessage data) : 
//	m_sourceIP(src), m_destIP(dest), m_destPort(destPort), m_payload(data)
//{
//	
//}