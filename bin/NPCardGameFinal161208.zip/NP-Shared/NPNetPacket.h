//#pragma once
//
//#include <SDL_Net.h>
//#include "NPNetMessage.h"
//
//class NPNetPacket
//{
//public:
//	NPNetPacket(void);
//	NPNetPacket(IPaddress src, IPaddress dest, short destPort, NPNetMessage data);
//
//public:
//	~NPNetPacket(void);
//public:
//	IPaddress	 m_sourceIP;
//	IPaddress	 m_destIP;
//	short		 m_destPort;
//
//	NPNetMessage m_payload;
//
//};
