#include "NPNetworkInterface.h"
#include "NPNetMessage.h"
#include "NPHelper.h"
#include "NPMessageTypes.h"

#include "SDL_thread.h"
#include "SDL_timer.h"
#include "SDL_mutex.h"
#include <assert.h>
#include <string>
#include <time.h>

///////////////////////////////////////////////////////////////////
// NPNetworkInterface                                            //
// This important threaded class deals with handling one send/rcv//
// pair between two interfaces, in this case, a server-client    //
// connection.                                                   //
///////////////////////////////////////////////////////////////////

SDL_mutex *lock;

NPNetworkInterface::NPNetworkInterface( char* debugName, bool allowMultClients )
{
	m_interfaceName = new char[128];
	memcpy( m_interfaceName, debugName, 128 );

	m_connected = false;
	m_socketRcv = 0;
	m_socketSend = 0;

	m_lastSuccessfulPing = 0;

	m_multClients = allowMultClients;
}

NPNetworkInterface::~NPNetworkInterface(void)
{
	delete(m_interfaceName);

	SDLNet_TCP_Close( m_socketSend );
	SDLNet_TCP_Close( m_socketRcv );
}

NPNetMessage NPNetworkInterface::GetNextMessage( bool toSend )
{
	// Note this function *removes* the 'front' message, and returns it to you.
	// It is then the callers responsibility to deal with the message

	NPNetMessage retVal(MSG_NULL);

	if ( toSend )
	{
		// Get the next message we want to send
		if ( m_messagesToSend.size() == 0 )
		{
			//printf( "Nothing waiting to be sent.\n" );
		}
		else
		{
			// lock for mutually exclusive access
			SDL_LockMutex(lock);
			//{
				retVal = m_messagesToSend.front();
				retVal.IncrSendAttempts(); //Increment the number of send attempts
				m_messagesToSend.pop();
			//}
			SDL_UnlockMutex(lock);

			printf("%s: Dealing with a sendable message ('%s') (now %d messages waiting to be sent)\n",
																	m_interfaceName,
																	retVal.GetData().c_str(),
																	m_messagesToSend.size() );
		}
	}
	else
	{
		// Get the next message we want to read
		if ( m_messagesReceived.size() == 0 )
		{
			//printf( "Nothing waiting to be read.\n" );
		}
		else
		{
			// lock for mutually exclusive access
			SDL_LockMutex(lock);
			{
				retVal = m_messagesReceived.front();
				m_messagesReceived.pop();
			}
			SDL_UnlockMutex(lock);

			printf("%s: Dealing with a readable message ('%s') (now %d messages left waiting to be read)\n",
																	m_interfaceName,
																	retVal.GetData().c_str(),
																	m_messagesReceived.size() );
		}
	}
	
	return retVal;
}

void NPNetworkInterface::AddNewMessage( NPNetMessage newMsg, bool toSend )
{	
	// This pushes a new message to the 'messages-to-send' queue

	if ( toSend )
	{
		// we're storing a new message ready to send
		SDL_LockMutex(lock);
		{
			m_messagesToSend.push( newMsg );
		}
		SDL_UnlockMutex(lock);
		printf("%s: +1 TO SEND: ('%s') (now %d ready to be sent)\n", m_interfaceName, 
																	 newMsg.GetData().c_str(), 
																	 m_messagesToSend.size() );
	}
	else
	{	
		// there is here a new recv'd message
		SDL_LockMutex(lock);
		{
			m_messagesReceived.push( newMsg );
		}
		SDL_UnlockMutex(lock);
		printf("%s: +1 RCV'D: ('%s') (now %d receieved, waiting to be dealt with.)\n", m_interfaceName,
																					   newMsg.GetData().c_str(),
																					   m_messagesReceived.size() );
	}
	
}

int NPNetworkInterface::ThreadUpdate( void* theInterface )
{
	// Threaded class
	// ensure we have not been passed null
	assert( theInterface != NULL );

	// allow the 'this' class object to be locked for mutex access
	lock = ( SDL_mutex* )theInterface;

	return ( static_cast< NPNetworkInterface* >(theInterface)->Update() );
}

void NPNetworkInterface::InitializeClient( const char* remoteIPAddress, unsigned short remotePort,
																			unsigned short localPort )
{
	// NB. All values passed to this function should be big endian, that is, "logical"
	// Initialize a fixed TCP Connection to a specified host at remoteIP
	m_connected = false;
	m_isClient = true;

	// our local IP doesn't really matter - it gets reset when we refresh anyway.
	m_localIP = NPHelper::GetIPaddress( "0.0.0.0", localPort );
	m_remoteIP = NPHelper::GetIPaddress( remoteIPAddress, remotePort );

	unsigned short port = 0;
	char ipAddr[30];
	NPHelper::GetReadableIPAddressPort( m_localIP, port );
	
	// Verify the listening socket
	// NB. Second argument is the specified host, NULL meaning IPADDR_ANY: i.e. rcv!
	if( SDLNet_ResolveHost( &m_localIP, NULL, port )== -1 )
	{
		printf( "SDLNet_ResolveHost: %s\n", SDLNet_GetError() );
		assert(0);
	}
	// Open the Listening socket
	m_socketRcv = SDLNet_TCP_Open( &m_localIP );
	if( !m_socketRcv )
	{
		printf( "URGENT!! Cannot open LOCAL port to read... multiple clients open! SDLNet_TCP_Open: %s\n", SDLNet_GetError() );
		
		// **README!**
		// This is a debug hack to allow multiple clients to exist from ONE source.
		//  Normally the server assumes that the client will open port 5000. Under _DEBUG 
		//  the server will expect that clients that it talks to will connect from ports 5000,
		//  5001, 5002..etc increasing through 5010
		// This call iteratively repeats this function until something sticks. It then 
		//  immediately exits, to ensure that the remainder only occurs once.
		// It is VERY hacky, but this code is for debug purposes ONLY, for testing multiple
		//  clients on one computer.
		if ( m_multClients )
		{
			InitializeClient( remoteIPAddress, remotePort, localPort+1 );
		}
		else
		{
			AddNewMessage( NPNetMessage(
				m_remoteIP,
				m_localIP,
				"Could not open local port: use any command line",
				MSG_CHAT_MESSAGE ), false );

			AddNewMessage( NPNetMessage(
				m_remoteIP,
				m_localIP,
				"arg to run 4 clients locally (debug mode).",
				MSG_CHAT_MESSAGE ), false );
		}

		return;

	}
	else
	{
		NPHelper::GetReadableIPAddress( m_localIP, ipAddr, true ); //unnecessary
		printf( "%s: * Listener started successfully on %s *\n", m_interfaceName, ipAddr );
		NPHelper::GetReadableIPAddress( m_remoteIP, ipAddr, true ); //unnecessary
		printf( "%s: * Remote IP is %s *\n", m_interfaceName, ipAddr );

		//*Finally* create the thread
		SDL_Thread *thread;
		thread = SDL_CreateThread( &NPNetworkInterface::ThreadUpdate, this );
		if ( thread == NULL )
		{
			printf( "%s: Unable to create thread: %s\n", m_interfaceName, SDL_GetError() );
			exit(3);
		}
	}
}
void NPNetworkInterface::InitializeServer( unsigned short serverPort )
{
	// NB. All values passed to this function should be big endian, that is, "logical"
	
	// Initialize a fixed TCP Connection to a specified host at remoteIP
	m_connected = false;
	m_isClient = false;

	// m_remoteIP here represents where the "client" is
	m_localIP.port = SDLNet_Read16(&serverPort); // serverPort MUST be BE, so m_localIP will be storing it as LE

	// Resolve the argument into an IPaddress type
	m_remoteIP = NPHelper::GetIPaddress( "255.255.255.255", 0 );

	char ipReadable[30];
	if ( RefreshConnection() )
	{
		NPHelper::GetReadableIPAddress( m_localIP, ipReadable, true );
		printf( "%s: Service started on %s *\n", m_interfaceName, ipReadable );
	}

	//*Finally* create the thread
	SDL_Thread *thread;
    thread = SDL_CreateThread( &NPNetworkInterface::ThreadUpdate, this );
    if ( thread == NULL )
	{
		printf( "%s: Unable to create thread: %s\n", m_interfaceName, SDL_GetError() );
		exit(3);
    }
}

bool NPNetworkInterface::HasRemoteConnection()
{
	// returns true if recently connected
	// each 10 calls, checks last good ping against current time

	static int i = 0; ++i;
	if ( i % 10 == 0 )
	{
		time_t now;
		time( &now );
		if ( ( now - m_lastSuccessfulPing ) < 10 )
		{
			// if last ping was less than 10 seconds ago
			m_connected = true;
		}
		else
		{
			m_connected = false;
		}
	}

	return m_connected;
}

bool NPNetworkInterface::RefreshConnection()
{
	// refresh our open connection to client or server
	// (we want to ensure our m_socketRcv is good)

	unsigned short port;
	char ipAddr[30];
	m_connected = false; // until proven true

	if ( !m_socketRcv )
	{
		NPHelper::GetReadableIPAddressPort( m_localIP, port );
		NPHelper::GetReadableIPAddress( m_localIP, ipAddr, false ); //unnecessary
		
		// NB. Second argument is the specified host, NULL meaning IPADDR_ANY: i.e. rcv!
		if( SDLNet_ResolveHost( &m_localIP, NULL, port )== -1 )
		{
			printf( "SDLNet_ResolveHost: %s\n", SDLNet_GetError() );
			assert(0);
			return false;
		}
		// open the (listening) socket
		m_socketRcv = SDLNet_TCP_Open( &m_localIP );
		if( !m_socketRcv )
		{
			printf( "URGENT!! Cannot open LOCAL port to read? SDLNet_TCP_Open: %s\n", SDLNet_GetError() );
			assert(0); // something is seriously wrong :|
			return false;
		}
		else
		{
			//SDLNet_TCP_Close( m_socketRcv );
		}
	}

	m_connected = true;
	return true;
}

bool NPNetworkInterface::SetRemotePort( unsigned short port )
{
	//port should be Big Endian (logical, readable)
	assert ( port >= 0 && port <= 65535 );

	char ipReadable[30];
	NPHelper::GetReadableIPAddress( m_remoteIP, ipReadable, false );
	printf( "%s: Redirecting port! We will now connect to %s:%u!\n", m_interfaceName, ipReadable, port );

	// mutex here?
	SDL_LockMutex(lock);
	{
		// switch to little endian and store
		m_remoteIP.port = SDLNet_Read16(&port);

		// close the sending socket - this will be picked up and reopened
		SDLNet_TCP_Close( m_socketSend );
	}
	SDL_UnlockMutex(lock);

	// force a refresh
	//RefreshConnection();
	
	return true;
}

bool NPNetworkInterface::SetRemoteIPAddress(IPaddress ipAddr, bool withPort)
{
	SDL_LockMutex(lock);
	{
		m_remoteIP.host = ipAddr.host;
		if ( withPort )
			m_remoteIP.port = ipAddr.port;
	}
	SDL_UnlockMutex(lock);


	if ( ( withPort && ( m_remoteIP.host == ipAddr.host && m_remoteIP.port == ipAddr.port ) ) ||
		   !withPort && ( m_remoteIP.host == ipAddr.host ) )
	{
		RefreshConnection();
		return true;
	}	
	return false;
}

bool NPNetworkInterface::SetLocalPort( unsigned short port )
{
	if ( port <= 0 || port > 65535 )
		return false;

	SDL_LockMutex(lock);
	{
		m_remoteIP.port = SDLNet_Read16(&port);
		RefreshConnection();
	}
	SDL_UnlockMutex(lock);

	return true;
}

int NPNetworkInterface::Update()
{
	// NB. In this CLASS we do NOT identify any messages: only store or send them!

	const int MSG_MAX_LENGTH = 1024;
	BYTE messageData[MSG_MAX_LENGTH];
	IPaddress newConnectionIP;
	char ipAddr[30];
	int messageLength;
	unsigned short port;
	BYTE* dataToSend = new BYTE[MSG_MAX_LENGTH]; //on heap!
	TCPsocket newConnection;

	while(1)
	{
		printf(".");
		// 1 listen
		//assert( m_socketRcv != NULL );
		
		newConnection = SDLNet_TCP_Accept( m_socketRcv );

		if ( newConnection )
		{
			// connection rcvd
			newConnectionIP = *( SDLNet_TCP_GetPeerAddress( newConnection ) );

			// print out the connectee IP and port number
			NPHelper::GetReadableIPAddress( newConnectionIP, ipAddr, true );
			printf( "%s: Accepting a new message from %s...\n", m_interfaceName, ipAddr );

			// read the buffer from remote connection
			messageLength = SDLNet_TCP_Recv( newConnection, messageData, MSG_MAX_LENGTH ); //stores in message
			
			if ( messageLength <= 0 )
			{
				// recvd weird message
				printf("%s: odd msg received!\n", m_interfaceName);
			}
			else
			{
				NPNetMessage newMsg( messageData, messageLength );

				// recvd message (base class) should deal with actually processing it!

				// ******************************************************************************
				// This step is important - a client has no awareness of it's own address
				//  when the server picks up the client, the server can deduce where the message
				//  came from. However the client will assume its OWN logical source as the source
				//  which is 0.0.0.0 so here we adjust the message so it follows logically.
				//
				// This also allows the server to recognise where the message has come from, and
				//  can then use this to send messages back.
				// ******************************************************************************
				if ( !m_isClient ) // if IS server
					newMsg.SetSource( newConnectionIP );
				
				AddNewMessage( newMsg, false );
			}
		}

		// 2 send
		if ( m_messagesToSend.size() > 0 )
		{
			printf("%s: Attempting to send a message...\n", m_interfaceName );

			NPNetMessage nextMsg = GetNextMessage( true );
			dataToSend = nextMsg.GetEncoded();
			m_remoteIP = nextMsg.GetDest();

			// attempt to send 
			if ( m_remoteIP.host == 0 && m_remoteIP.port == 0 )
			{
				// do not send - ignore message (has already been popped, should not be pushed back)
			}
			else
			{

				NPHelper::GetReadableIPAddressPort( m_remoteIP, port );
				NPHelper::GetReadableIPAddress( m_remoteIP, ipAddr, false );

				if( SDLNet_ResolveHost( &m_remoteIP, ipAddr, port )== -1 )
				{
					printf( "%s: SDLNet_ResolveHost: %s\n", m_interfaceName, SDLNet_GetError() );
					assert(0);
					return false;
				}
				// open the (sending) socket
				m_socketSend = SDLNet_TCP_Open( &m_remoteIP );

				if ( !m_socketSend )
				{
					printf("%s: Cannot connect for some reason!\n", m_interfaceName );

					// We have had to use GetNextMessage to peek at the destination
					// so in the event of disaster, we should replace the message.
					AddNewMessage( nextMsg, true );
				}
				else
				{

					printf("%s: Sending '%s' to %s ...", m_interfaceName, nextMsg.GetData().c_str(), ipAddr );

					int result = SDLNet_TCP_Send( m_socketSend,
												  dataToSend,
												  nextMsg.GetTotalSize() );// add one for the message type

					// if failed...
					if( result != nextMsg.GetTotalSize() )
					{
						printf("%s: SDLNet_TCP_Send: %s\n", m_interfaceName, SDLNet_GetError());
						AddNewMessage( nextMsg, true ); //best put it back on then.
					}
					
					// if successful...
					if ( result == nextMsg.GetTotalSize() )
					{
						printf("%s: Successfully sent!\n", m_interfaceName);
					}
					
					//SDLNet_TCP_Close( m_socketSend );
				}
			}
		}

		// 3 pause
		SDL_Delay( SOCKET_RW_DELAY );

		//// 4 purge stale msgs
		//if ( m_doPurgeStaleMsgs )
		//	PurgeStaleMessages();
	}

	delete dataToSend;
	return 0;
}


void NPNetworkInterface::SuccessfulPing()
{
	m_lastSuccessfulPing = time(0);
}
bool NPNetworkInterface::PurgeStaleMessages()
{
	assert( m_isClient == false ); //not rdy for client use - do this
	// This should remove all messages that simply aren't sending
	// returns true when something has been purged
	bool retVal = false;

	// wide mutex - if m_messagesToSend were to change while we do this, Bad Things� could happen!
	SDL_LockMutex(lock);
	{
		for ( unsigned int i = 0; i < m_messagesToSend.size(); ++i )
		{
			NPNetMessage nextMsg = m_messagesToSend.front();
			m_messagesToSend.pop();

			if ( nextMsg.GetSendAttempts() > SEND_ATTEMPT_THRESHOLD )
			{
				// we are purging this message!
				printf("%s: Purging a message that isn't sending! *(Type: %u Content %s)\n", m_interfaceName,
																							nextMsg.GetMessageType(),
																							nextMsg.GetData().c_str() );
				char ipAddr[30];
				NPHelper::GetReadableIPAddress( nextMsg.GetDest(), ipAddr, true );

				// Add a messages to ourselves that we should purge this IP from memory
				AddNewMessage( NPNetMessage( GetLocalIPAddress(), 
											 GetLocalIPAddress(),
											 std::string(ipAddr),
											 MSG_PURGE_THIS_IP ), false );

				retVal = true;
			}
			else
			{
				// legal message, still to be sent
				// as we've taken it off the front, push it back on the back (queue)
				m_messagesToSend.push( nextMsg );
			}
		}
	}
	SDL_UnlockMutex(lock);

	m_doPurgeStaleMsgs = false; //work is done, set this to false

	return retVal;
}