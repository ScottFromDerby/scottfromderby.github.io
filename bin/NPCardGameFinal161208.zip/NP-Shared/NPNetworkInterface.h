#pragma once

#include "SDL_net.h"

#include <queue>
#include <string>
#include <time.h>

#include "NPNetMessage.h"

#define SOCKET_RW_DELAY 10
#define CLIENT_LISTEN_PORT 5000

// num times to attempt sending before giving up
#define SEND_ATTEMPT_THRESHOLD 3


class NPNetworkInterface
{
public:
	NPNetworkInterface( char* nameDebug, bool allowMultClients );
	~NPNetworkInterface( void );

public:
	void InitializeClient( const char* ipAddress, unsigned short remotePort, unsigned short localPort );
	void InitializeServer( unsigned short localPort );

	int Update();

	int ClientUpdate();
	int ServerUpdate();

public:
	static int ThreadUpdate( void* selfReferencialPtr );

public:
	NPNetMessage GetNextMessage( bool toSend );
	void AddNewMessage( NPNetMessage newMsg, bool messageToSend );

	bool RefreshConnection();
	bool HasRemoteConnection();

	// hash - writeup!
	static unsigned int Hash() { return m_interfaceHash; }

public:
	Uint32 GetLocalIP() { return m_localIP.host; }
	Uint16 GetLocalPort() { return m_localIP.port; }
	IPaddress GetLocalIPAddress() { return m_localIP; }
	IPaddress GetRemoteIPAddress() { return m_remoteIP; }
	bool PurgeStaleMessages();

	bool SetRemoteIPAddress(IPaddress ipAddr, bool withPort);
	bool SetRemotePort( unsigned short port );
	bool SetLocalPort( unsigned short port );

	char* GetInterfaceName() { return m_interfaceName; }

	void SuccessfulPing();

	void RequestPurgeOldMessages() { m_doPurgeStaleMsgs = true; }

private:
	std::queue<NPNetMessage> m_messagesReceived; // queue! (FIFO) to hold msgs that have been rcvd
	std::queue<NPNetMessage> m_messagesToSend;	 // to hold msgs that should be sent when next possible

	char* m_interfaceName;				 // a user/log-friendly name to identify this interface
	static unsigned int m_interfaceHash; // this should uniquely identify the interface

	// *****************************************************************
	// m_localIP and m_remoteIP are context-based
	// as a client interface, local represents the client, and remote represents the server
	// as a server interface, local represents the server, and m_remoteIP is the client
	// *****************************************************************

	bool m_isClient;		// will defintely attempt to connect to a server!

	// if (m_isClient), this is the client. Otherwise this is the server.
	IPaddress m_localIP;    // the IP of the interface, used to rcv msgs
	TCPsocket m_socketRcv;  // the socket used to receive

	// if (m_isClient), this is the serverIP. Otherwise this is a temporary reuasable client IP.
	IPaddress m_remoteIP;	// the IP of the remote, foreign, target host
	TCPsocket m_socketSend; // the socket used to send

	bool m_connected;		// whether or not this interface is attached to another interface

	time_t m_lastSuccessfulPing; // last time a successful ping was made
	bool m_doPurgeStaleMsgs;	 // set to true if the server *thread* should do PurgeStaleMessages()

public:
	bool m_multClients;	// allow multiple clients from one PC
						// this makes the client retry on increasing ports
						// and makes the server assume each client is connecting on increasing ports

};