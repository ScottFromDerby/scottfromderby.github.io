#include "SDLRenderer.h"
#include <math.h>
#include <assert.h>

////////////////////////////////////////////////////
// SDLRenderer                                    //
// A simple *generic* SDL Renderer class          //
// compiled by Scott Davies  2008                 //
////////////////////////////////////////////////////

SDLRenderer::SDLRenderer(void)
{
}

SDLRenderer::~SDLRenderer(void)
{
	delete(m_pScreen);
	m_pScreen = 0;
	TTF_CloseFont( m_defaultFont );
}

int SDLRenderer::Init( unsigned short xSize, unsigned short ySize, char* defaultFontPath )
{
	// Initialize SDL's subsystems - video
	if ( SDL_Init(SDL_INIT_VIDEO) < 0 ) 
	{
		fprintf( stderr, "Unable to init SDL: %s\n", SDL_GetError() );
		return -1;
	}

	// Attempt to create a window with 32bit pixels.
	m_pScreen = SDL_SetVideoMode( xSize, ySize, 32, SDL_SWSURFACE );
	assert( m_pScreen != NULL ); // could not set up window

	// Initialize SDL_ttf
	TTF_Init();
    atexit(TTF_Quit); // remind ourselves to call this on exit

	m_defaultFont = TTF_OpenFont( defaultFontPath, 13 );

	assert( m_defaultFont != 0 ); // could not load font!

	return 0;
}

void SDLRenderer::PutPixel( unsigned short x, unsigned short y, unsigned int color )
{
	if ( x >= GetScreenWidth() || y >= GetScreenHeight() || x < 0 || y < 0 )
		return;
	
	unsigned int *ptr = (unsigned int*)m_pScreen->pixels;
	int lineoffset = y * (m_pScreen->pitch / 4);
	ptr[lineoffset + x] = color;
}

void SDLRenderer::DrawRect( unsigned short x, unsigned short y, unsigned short width,
													unsigned short height, unsigned int colour )
{
	//for ( int i = 0; i < width; ++i)
	//{	
	//	for ( int j = 0; j < height; ++j)
	//	{	
	//		PutPixel(x+i,y+j,colour);
	//	}
	//}

	int i, j;
	for (i = 0; i < height; i++)
	{
		// vertical clipping: (top and bottom)
		if ((y + i) >= 0 && (y + i) < GetScreenHeight())
		{
			int len = width;
			int xofs = x;

			// left border
			if (xofs < 0)
			{
				len += xofs;
				xofs = 0;
			}

			// right border
			if (xofs + len >= GetScreenWidth())
			{
				len -= (xofs + len) - GetScreenWidth();
			}
			int ofs = (i + y) * GetScreenPitch() + xofs;

			// note that len may be 0 at this point, 
			// and no pixels get drawn!
			for (j = 0; j < len; j++)
				((unsigned int*)m_pScreen->pixels)[ofs + j] = colour;
		}
	}

}

void SDLRenderer::DrawCircle( unsigned short x, unsigned short y, unsigned short radius, unsigned int colour )
{
	int h = GetScreenHeight();
	int w = GetScreenWidth();
	int p = GetScreenPitch();

	unsigned short i, j;
	for (i = 0; i < 2 * radius; i++)
	{
		// vertical clipping: (top and bottom)
		if ( (y - radius + i) >= 0 && (y - radius + i) < GetScreenHeight() )
		{
			int len = (int)sqrt((float)(radius * radius - (radius - i) * (radius - i))) * 2;
			int xofs = x - len / 2;

			// left border
			if (xofs < 0)
			{
				len += xofs;
				xofs = 0;
			}

			// right border
			if ( xofs + len >= GetScreenWidth() )
			{
				len -= (xofs + len) - GetScreenWidth();
			}
			int ofs = (y - radius + i) * GetScreenPitch() + xofs;

			// note that len may be 0 at this point, 
			// and no pixels get drawn!
			for (j = 0; j < len; j++)
				((unsigned int*)m_pScreen->pixels)[ofs + j] = colour;
		}
	}	
}
void SDLRenderer::StartDrawing()
{
	// Start of every frame!

	// Lock surface if needed
	//if (SDL_LockSurface( m_pScreen ) < 0)
	//	return;

	// fill background
	DrawRect(0, 0, GetScreenWidth(), GetScreenHeight(), BG_COLOUR); 

	// draw frame
	DrawRect(0, 0, GetScreenWidth(), FRAME_SIZE, FRAME_COLOUR); 
	DrawRect(0, 0, FRAME_SIZE, GetScreenHeight()-FRAME_SIZE, FRAME_COLOUR); 
	DrawRect(0, GetScreenHeight()-FRAME_SIZE, GetScreenWidth(), GetScreenHeight(), FRAME_COLOUR); 
	DrawRect(GetScreenWidth()-FRAME_SIZE, 0,  GetScreenWidth(), GetScreenHeight(), FRAME_COLOUR); 
}

void SDLRenderer::EndDrawing()
{
	// End of every frame!

	// Unlock if needed
	//if (SDL_MUSTLOCK(m_pScreen)) 
	//	SDL_UnlockSurface(m_pScreen);

	// Tell SDL to update the whole screen
	SDL_UpdateRect(m_pScreen, 0, 0, GetScreenWidth(), GetScreenHeight());
}

void SDLRenderer::DrawString( unsigned short x, unsigned short y, const char* msg, unsigned int colour )
{
	SDL_Color c;
	c.r = colour >> 16;
	c.g = colour >> 8;
	c.b = colour;
	c.unused = 255;

	SDL_Surface *sText = TTF_RenderText_Solid( m_defaultFont, msg, c );
	if ( sText == NULL )
	{
		//printf("*Error: %s*\n", SDL_GetError() );
	}
	else
	{
		SDL_Rect rcDest = { x, y, x+sText->clip_rect.w, y+sText->clip_rect.h };
		SDL_BlitSurface( sText, 0, m_pScreen, &rcDest );
	}
	SDL_FreeSurface( sText );
}

void SDLRenderer::DrawSurface( SDL_Surface* in, unsigned short x, unsigned short y )
{
	SDL_Rect rcDest = { x, y, (x+in->w), (y+in->h) };
	SDL_BlitSurface( in, 0, m_pScreen, &rcDest );
}