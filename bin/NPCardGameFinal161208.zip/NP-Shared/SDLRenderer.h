#pragma once

#include "SDL.h"
#include "SDL_image.h"
#include "SDL_ttf.h"


class SDLRenderer
{
public:
	SDLRenderer(void);
	~SDLRenderer(void);
public:
	int Init( unsigned short xScreenSize, unsigned short yScreenSize, char* defaultFontPath );

	void StartDrawing();
	void EndDrawing();

	void PutPixel( unsigned short x, unsigned short y, unsigned int color );
	void DrawRect( unsigned short x, unsigned short y, unsigned short width, unsigned short height,
																					unsigned int colour );
	void DrawCircle( unsigned short x, unsigned short y, unsigned short radius, unsigned int colour );
	void DrawString( unsigned short x, unsigned short y, const char* msg, unsigned int colour );
	void DrawSurface( SDL_Surface* in, unsigned short x, unsigned short y );

	SDL_Surface* GetScreen(void) { return m_pScreen; }
	void SetScreen(SDL_Surface* newScreen) { m_pScreen = newScreen; }
	inline int GetScreenHeight(void) { return m_pScreen->h; }
	inline int GetScreenWidth(void) { return m_pScreen->w; }
	inline unsigned short GetScreenPitch(void) { return m_pScreen->pitch / 4; }

private:
	SDL_Surface *m_pScreen;
	TTF_Font *m_defaultFont;
};

#define BG_COLOUR 0x000000
//#define FRAME_COLOUR 0x660011
#define FRAME_COLOUR 0xdddddd
#define FRAME_SIZE 2